package com.anthem.microsvc.wso2greg.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import com.anthem.microsvc.wso2greg.util.WSO2Utility;

@RunWith(MockitoJUnitRunner.class)
public class WSO2UtilityTest {

	@Test
	public void createAssociationPathEndpointTest() {
		String endpoint = "/v1/ir/members/{mbrUid}/telephone";
		String api = "eligibility";
		
		try {
			assertNotNull(WSO2Utility.createAssociationPathEndpoint(api, endpoint));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void extactDBNameTest() {
		
		Map<String, Object> properties = new HashMap<>();
		
		properties.put("ehubblue.datasource.url", "jdbc:oracle:thin:@hostname.wellpoint.com:1525/schema");
		properties.put("mongodb.datasource.sydneydb.connectionstring", "mongodb://test:test@hostname.wellpoint.com:37043/SAMPLEDB"); 
		
		if(properties.values().stream().anyMatch(v -> v.toString().contains(":oracle:"))) {
    		String property =properties.values().stream().filter(v -> v.toString().contains(":oracle:")).findFirst().get().toString();
    		String dbName = property.substring(property.lastIndexOf("/")+1, property.length());
    		
    		System.out.println(dbName);
    	}if(properties.values().stream().anyMatch(v -> v.toString().contains("mongodb:"))) {
    		String property = properties.values().stream().filter(v -> v.toString().contains("mongodb:")).findFirst().get().toString();
    		
    		String dbName = property.substring(property.lastIndexOf("/")+1, property.indexOf("?") != -1 ? property.indexOf("?"):property.length());
    		System.out.println(dbName);
    	}
	}
	
	@Test
	public void createEndPointTest() {
		String endpoint = "/v7/cp/members/*/servicenumber/";
		endpoint = endpoint.replaceAll("/\\{", "/\\$").replaceAll("\\}/", "/").replaceAll("\\*", "\\$");
		if(endpoint.indexOf("}")>-1) {
			endpoint = endpoint.substring(0, endpoint.indexOf("}"));
		}
		System.out.println(endpoint);
	}
	
	/*@Test
	public void deleteDirTest() {
		String svcName = "arcreatedigitalaccount";
		//assertTrue(WSO2Utility.deleteDir(svcName));
		assertTrue(deleteDirectory(svcName));
	}
	public boolean deleteDirectory(String svcName) {
		File dir = new File(WSO2Utility.getFolderPath() + svcName);
		boolean deleted = deleteDirectory(dir);
		return deleted;
	}
	private boolean deleteDirectory(File directoryToBeDeleted) {
	    File[] allContents = directoryToBeDeleted.listFiles();
	    if (allContents != null) {
	        for (File file : allContents) {
	            deleteDirectory(file);
	        }
	    }
	    return directoryToBeDeleted.delete();
	}*/
	
	/*@Test
	public void parseBootstrapForMongoTest() {
			
			String bootstrap = WSO2Utility.getFolderPath() + service + "\\src\\main\\resources\\bootstrap.yml";

			Yaml yaml = new Yaml();
			String configUrl = "";
			try {
				InputStream inputStream = new FileInputStream(bootstrap);
				for (Object object : yaml.loadAll(inputStream)) {
					LinkedHashMap map = (LinkedHashMap) object;
					if (!MapUtils.isEmpty(map) && (map.get("spring").toString().contains("profiles=" + "uat"))) {
						if(map.get("mongodb") != null && map.get("mongodb").toString().contains("uri"))
						{
							//String uri = map.get("mongodb").toString().split("uri=")[1].split("}")[0];
							String uri = ((LinkedHashMap)map.get("mongodb")).get("uri").toString();
							System.out.println(uri);
							break;
						}
						
					}
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}*/
	
	
	@Test
	public void testRegularExpr() {
		String endpoint = "v7/cp/products/{benefitKey}/prodtype";
		
		System.out.println(endpoint.substring(0, endpoint.indexOf('{')+1)+"%%"+endpoint.substring(endpoint.indexOf('}')));
		
	}
}
