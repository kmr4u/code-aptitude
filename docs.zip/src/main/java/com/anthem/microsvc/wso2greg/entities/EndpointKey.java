package com.anthem.microsvc.wso2greg.entities;

import java.io.Serializable;

public class EndpointKey implements Serializable{

	private int proxy_id;
	private String api;
	private String http_verb;
	private String resource_path;
	
	public EndpointKey() {
		
	}
	
	public EndpointKey(int id, String api, String verb, String resourcePath) {
		this.proxy_id = id;
		this.api = api;
		this.http_verb = verb;
		this.resource_path = resourcePath;
	}

	public int getProxy_id() {
		return proxy_id;
	}

	public void setProxy_id(int proxy_id) {
		this.proxy_id = proxy_id;
	}

	public String getApi() {
		return api;
	}

	public void setApi(String api) {
		this.api = api;
	}

	
	public String getResource_path() {
		return resource_path;
	}

	public void setResource_path(String resource_path) {
		this.resource_path = resource_path;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((api == null) ? 0 : api.hashCode());
		result = prime * result + proxy_id;
		result = prime * result + ((resource_path == null) ? 0 : resource_path.hashCode());
		result = prime * result + ((http_verb == null) ? 0 : http_verb.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EndpointKey other = (EndpointKey) obj;
		if (api == null) {
			if (other.api != null)
				return false;
		} else if (!api.equals(other.api))
			return false;
		if (proxy_id != other.proxy_id)
			return false;
		if (resource_path == null) {
			if (other.resource_path != null)
				return false;
		} else if (!resource_path.equals(other.resource_path))
			return false;
		if (http_verb == null) {
			if (other.http_verb != null)
				return false;
		} else if (!http_verb.equals(other.http_verb))
			return false;
		return true;
	}

	public String getHttp_verb() {
		return http_verb;
	}

	public void setHttp_verb(String http_verb) {
		this.http_verb = http_verb;
	}
	
}
