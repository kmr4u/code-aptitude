package com.anthem.microsvc.wso2greg.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "consumer", schema = "inventory")
public class Consumer implements Serializable{

	
	private int consumer_id;
	private String consumer_name;
	
	
	private Set<Proxy> proxies = new HashSet<>();
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "consumer_id")
	public int getConsumer_id() {
		return consumer_id;
	}
	public void setConsumer_id(int consumer_id) {
		this.consumer_id = consumer_id;
	}
	@Column(name = "consumer_name")
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	
	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "consumers")
	public Set<Proxy> getProxies() {
		return proxies;
	}
	public void setProxies(Set<Proxy> proxies) {
		this.proxies = proxies;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + consumer_id;
		result = prime * result + ((consumer_name == null) ? 0 : consumer_name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Consumer other = (Consumer) obj;
		if (consumer_id != other.consumer_id)
			return false;
		if (consumer_name == null) {
			if (other.consumer_name != null)
				return false;
		} else if (!consumer_name.equals(other.consumer_name))
			return false;
		return true;
	}
}
