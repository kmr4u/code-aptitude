package com.anthem.microsvc.wso2greg;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.anthem.microsvc.wso2greg.repositories.GovRegRepositoryService;


/**
 * Docker MS Prototype!
 *
 */

@SpringBootApplication
@ComponentScan(value = { "com.anthem" })
@RefreshScope
@RestController
@EnableAutoConfiguration
@EnableConfigurationProperties
public class Application 
{
	
	@Value("${defaultConnectionTimeout}")
    private int connectionTimeout;
	
	@Value("${defaultReadTimeout}")
    private int readTimeout;
	
	@Autowired
	GovRegRepositoryService service;
	
    public static void main( String[] args )
    {
    	SpringApplication.run(Application.class, args);        
    }
    
    
    @Bean
	public RestTemplate restTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException{
    	TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
            @Override
            public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                return true;
            }
        };
        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        requestFactory.setConnectTimeout(15000);
        requestFactory.setReadTimeout(15000);
        RestTemplate restTemplate = new RestTemplate(requestFactory);
		
		/*((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setConnectTimeout(connectionTimeout);
		((SimpleClientHttpRequestFactory)restTemplate.getRequestFactory()).setReadTimeout(readTimeout);	*/	
    	
    	/*RestTemplate restTemplate = null;
        try {
              TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
              SSLContext sslContext;
              sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
              SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
              CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
              HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
              requestFactory.setHttpClient(httpClient);
              restTemplate = new RestTemplate(requestFactory);
        } catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
              
        }*/
        return restTemplate;

	}
    
    
}
