package com.anthem.microsvc.wso2greg.repositories;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.microsvc.wso2greg.entities.MsInventory;

@Repository
@Transactional
public interface MsInventoryRepository extends CrudRepository<MsInventory, String>{

	@Transactional
	@Query("SELECT a FROM MsInventory a where a.service=:service")	
	public List<MsInventory> getContextRoot(@Param(value = "service")String service);
	
	@Transactional
	@Query("select a from MsInventory a where a.service in :services")
	public List<MsInventory> getAllServicesWithContextRoots(@Param(value = "services") Set<String> services);
}
