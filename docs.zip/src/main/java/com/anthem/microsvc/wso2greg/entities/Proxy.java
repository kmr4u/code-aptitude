package com.anthem.microsvc.wso2greg.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "proxy", schema = "inventory")
public class Proxy implements Serializable{
	
	
	private int proxy_id;
	
	
	private String proxy;
	
	
	private String basePath;
	
	
	private List<Endpoint> endPoints = new ArrayList<>();
	
	
	private Set<Consumer> consumers = new HashSet<>();
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getProxy_id() {
		return proxy_id;
	}
	
	public void setProxy_id(int proxy_id) {
		this.proxy_id = proxy_id;
	}
	
	@Column(name = "proxy_name")
	public String getProxy() {
		return proxy;
	}
	public void setProxy(String proxy) {
		this.proxy = proxy;
	}

	@Column(name = "base_path")
	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	@OneToMany(/*mappedBy = "proxy",*/ cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinTable(name = "PROXY_ENDPOINT", joinColumns = @JoinColumn(name = "proxy_id"), inverseJoinColumns=@JoinColumn(name = "id"))
	public List<Endpoint> getEndPoints() {
		return endPoints;
	}

	public void setEndPoints(List<Endpoint> endPoints) {
		this.endPoints = endPoints;
	}

	@ManyToMany(cascade = CascadeType.ALL/*mappedBy = "proxies"*/, fetch = FetchType.LAZY)
	@JoinTable(name = "PROXY_CONSUMER", joinColumns = @JoinColumn(name = "proxy_id"), inverseJoinColumns=@JoinColumn(name = "consumer_id"))
	public Set<Consumer> getConsumers() {
		return consumers;
	}

	public void setConsumers(Set<Consumer> consumers) {
		this.consumers = consumers;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((basePath == null) ? 0 : basePath.hashCode());
		result = prime * result + ((consumers == null) ? 0 : consumers.hashCode());
		result = prime * result + ((proxy == null) ? 0 : proxy.hashCode());
		result = prime * result + proxy_id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Proxy other = (Proxy) obj;
		if (basePath == null) {
			if (other.basePath != null)
				return false;
		} else if (!basePath.equals(other.basePath))
			return false;
		if (consumers == null) {
			if (other.consumers != null)
				return false;
		} else if (!consumers.equals(other.consumers))
			return false;
		if (proxy == null) {
			if (other.proxy != null)
				return false;
		} else if (!proxy.equals(other.proxy))
			return false;
		if (proxy_id != other.proxy_id)
			return false;
		return true;
	}
	
}