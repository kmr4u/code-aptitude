package com.anthem.microsvc.wso2greg.model;

import java.util.List;

public class AddEndpointRequest {

	private String proxyName;
	private List<Resource> resourceList;
	
	public String getProxyName() {
		return proxyName;
	}
	public void setProxyName(String proxyName) {
		this.proxyName = proxyName;
	}
	public List<Resource> getResourceList() {
		return resourceList;
	}
	public void setResourceList(List<Resource> resourceList) {
		this.resourceList = resourceList;
	}
	
	
}
