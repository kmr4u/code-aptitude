package com.anthem.microsvc.wso2greg.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Constants {
	
	public static final String USER_DIR = "user.dir";
	public static final String BACK_SLASH = "/";
	
	public static final String ENCODING_UTF8 = "UTF-8";
		
	//public static final String WSO2URI = "https://ip-22-172-4-115.aws.internal.das:9443";
	
	public static final String LOCAL_ADD_ASSET = "/assets/add";
	
	public static final String ADD_RESOURCE_REST = "/governance/restservices";
	
	public static final String ADD_RESOURCE_APIGEE = "/governance/apiproxys";
	
	public static final String ADD_RESOURCE_CONSUMERS = "/governance/apiconsumers";
	
	public static final String ADD_RESOURCE_DOMAINS = "/governance/domainss";
	
	public static final String ADD_RESOURCE_SDS = "/governance/ehubsdss";
	
	public static final String ADD_RESOURCE_MICROSDS = "/governance/microsdss";
	
	public static final String ADD_RESOURCE_ENDPOINT = "/governance/endpoints";
	
	//public static final String WSO2_CREDS = "Basic YWRtaW46YWRtaW4=";
	
	public static final String ADD_RESOURCE_ASSOCIATION = "/resource/1.0.0/associations";
	
	public static final String REST_ASSOCIATION_PATH = "/_system/governance/trunk/restservices/1.0/";
	
	public static final String REST_ASSOCIATION_PROXY = "/_system/governance/trunk/apiproxy/";
	
	public static final String REST_ASSOCIATION_CONSUMER = "/_system/governance/trunk/apiconsumer/";
	
	public static final String GET_APIPROXIES = "/governance/apiproxys";
	
	public static final String ADD_ENDPOINTS_APIPROXIES_ASSOCIATION = "/governance/endpoints/apiproxys?name=";
	public static final String ADD_ENDPOINTS_RESTSERVICE_ASSOCIATION = "/governance/endpoints/restservices?name=";
	
	public static final String SDS_PATH = "/_system/governance/trunk/ehubsds/";
	
	public static final String MICROSDS_PATH = "/_system/governance/trunk/microsds/";
	
	public static final String REST_DOMAINS_PATH = "/_system/governance/trunk/domains/";
	
	public static final String REST_ASSOCIATION_ENDPOINT = "/_system/governance/trunk/endpoints/";
	
	public static final String OWNED_BY_ASSOCIATION = "ownedby";
	
	public static final List<String> KEYS = Arrays.asList("uri", "url", "connectionString", "Url", "connectionstring");
	
	public static final Map<String, String> DOMAIN;
	private static Map<String, String> DOMAIN_MAP;
	static {
		DOMAIN_MAP = new HashMap<>();
		DOMAIN_MAP.put("SOADMBR", "Member");
		DOMAIN_MAP.put("SOADUTL", "Utility");
		DOMAIN_MAP.put("SOADPDT", "Benefits");
		DOMAIN_MAP.put("NEXGENENG", "NEXGENENG");
		DOMAIN_MAP.put("SOADCLM", "Claims");
		DOMAIN = Collections.unmodifiableMap(DOMAIN_MAP);
	}
	
	public static final Map<String, String> EHUB;
	private static Map<String, String> EHUB_URLS;
	static {
		EHUB_URLS = new HashMap<>();
		EHUB_URLS.put("ehub.datasource", "ehub.datasource.url");
		EHUB_URLS.put("ehubblue.datasource", "ehubblue.datasource.url");
		EHUB_URLS.put("mongodb.uri", "mongodb.uri");
		EHUB = Collections.unmodifiableMap(EHUB_URLS);
	}
}
