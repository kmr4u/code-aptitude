package com.anthem.microsvc.wso2greg.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.anthem.microsvc.wso2greg.entities.Consumer;
import com.anthem.microsvc.wso2greg.entities.Endpoint;
import com.anthem.microsvc.wso2greg.entities.MsInventory;
import com.anthem.microsvc.wso2greg.entities.Proxy;
import com.anthem.microsvc.wso2greg.repositories.ApiProxyRepo;
import com.anthem.microsvc.wso2greg.repositories.EndpointRepository;
import com.anthem.microsvc.wso2greg.repositories.GovRegRepositoryService;
import com.anthem.microsvc.wso2greg.repositories.MsInventoryRepository;
import com.anthem.microsvc.wso2greg.service.GovernanceDBService;

@Component
public class GovernanceDBServiceImpl implements GovernanceDBService {
	private static final Logger logger = LoggerFactory.getLogger(GovernanceDBService.class);
	@Autowired
	private GovRegRepositoryService govRegRepo;
	
	@Autowired
	private MsInventoryRepository msRepo;
	
	@Autowired
	private ApiProxyRepo proxyRepo;
	
	@Autowired
	private EndpointRepository endpointRepo;
	
	@Override
	public String getContextRoot(String servicename) {
		logger.info("Method Enter: getContextRoot("+servicename+")");
		List<MsInventory> res = null;
		
		try {
			res = msRepo.getContextRoot(servicename);
			if(!CollectionUtils.isEmpty(res)){
				logger.info("Method Exit: getContextRoot()");
				return res.get(0).getContextRoot();
			}
		}catch(Exception e) {
			throw e;
		}
		
		logger.info("Method Exit: getContextRoot(). ContextRoot is null");
		return null;
	}

	@Override
	public List<Proxy> getAPIGEEProxy(String contextRoot) {
		logger.info("Method Enter: getAPIGEEProxy("+contextRoot+")");
		List<Proxy> res = null;
		try {
			res = proxyRepo.getApigeeProxiesFromContextRoot(contextRoot);
			if(!CollectionUtils.isEmpty(res)) {
				logger.info("Method Exit: getAPIGEEProxy()");
				return res;
			}
		}catch(Exception e) {
			throw e;
		}
		logger.info("Method Exit: getAPIGEEProxy(). No proxies found");
		return null;
	}

	@Override
	public List<Object[]> getAPIGEEProxyEndpoint() {
		
		//List<ApiProxy> res = null;
		List<Object[]> res = null;
		try {
			res = proxyRepo.getAllEndpoints();
			if(!CollectionUtils.isEmpty(res)) {
				return res;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public Map<String, List<Proxy>> getAPIGEEProxyByResourceName(List<String> resourcePaths) {
		
		Map<String, List<Proxy>> proxiesMap = new HashMap<>();
		try {
			for(String endpoint: resourcePaths) {
				if(StringUtils.hasText(endpoint)) {
					if(endpoint.endsWith("/")) {
						endpoint = endpoint.substring(0, endpoint.lastIndexOf("/"));
					}
					if(endpoint.indexOf('?') > -1) {
						endpoint = endpoint.substring(0, endpoint.indexOf('?'));
					}
					if(endpoint.indexOf('{') > -1 && endpoint.indexOf('}') > -1) {
						endpoint = endpoint.substring(0, endpoint.indexOf('{')+1)+"%%"+endpoint.substring(endpoint.indexOf('}'));
					}
					List<Proxy> proxies = proxyRepo.getProxyFromBasePath(endpoint);
					if(!CollectionUtils.isEmpty(proxies)) {
						List<Proxy> list = proxiesMap.getOrDefault(proxiesMap.get("proxy"), new ArrayList<Proxy>());
						list.addAll(proxies);
						proxiesMap.put("proxy", list);
						//res.addAll(proxies);
						continue;
					}
					List<Proxy> proxy = proxyRepo.getApiProxiesFromEndpoint(endpoint);
					if(!CollectionUtils.isEmpty(proxy)) {
						List<Proxy> list = proxiesMap.get("endpoint");
						if(!CollectionUtils.isEmpty(list)) {
							list.addAll(proxy);
							proxiesMap.put("endpoint", list);
						}else {
							proxiesMap.put("endpoint", proxy);
						}
						
						//res.addAll(proxy);
						
					}
				}
				
			}
		}catch(Exception e) {
			throw e;
		}
		return proxiesMap;
	}

	@Override
	public List<Object[]> getAllProxies() {
		
		List<Object[]> res = null;
		try {
			res = proxyRepo.getAllProxies();
		}catch(Exception e) {
			throw e;
		}
		
		return res;
	}

	@Override
	public List<Proxy> getAllConsumers() {

		List<Proxy> res = null;
		try {
			res = proxyRepo.getAllProxyConsumers();
		}catch(Exception e) {
			throw e;
		}
		
		return res;
	}

	@Override
	public Set<String> getAllServicesWithContextRoots(Set<String> services) {
		Set<String> ms = new HashSet<>();
		List<MsInventory> res = null;
		try {
			res = msRepo.getAllServicesWithContextRoots(services);
			if(!CollectionUtils.isEmpty(res)) {
				for(MsInventory row: res) {
					ms.add(row.getService());
				}
			}
		}catch(Exception e) {
			throw e;
		}
		return ms;
	}

	@Override
	public void saveApiProxies(Iterable<Proxy> proxies) {
		// TODO Auto-generated method stub
		//govRegRepo.save(proxies);
		
		proxyRepo.save(proxies);
	}

	@Override
	public void saveMsInventory(List<MsInventory> ms) {
		// TODO Auto-generated method stub
		//govRegRepo.save(ms);
		msRepo.save(ms);
	}

	@Override
	public void addNewMs(String servicenm, String contextRt) {
		
		MsInventory ms = new MsInventory();
		ms.setService(servicenm);
		ms.setContextRoot(contextRt);
		
		msRepo.save(ms);
		
	}

	@Override
	public void addNewProxy(String proxyName, String basePath) {
		
		Proxy proxy = new Proxy();
		proxy.setProxy(proxyName);
		proxy.setBasePath(basePath);
		
		proxyRepo.save(proxy);
		
	}

	@Override
	public void addNewProxyResources(List<Endpoint> resources, String proxyName) {
		
		List<Proxy> proxies = proxyRepo.findProxyByName(proxyName);
		if(!CollectionUtils.isEmpty(proxies)) {
			Proxy proxy = proxies.get(0);
			for(Endpoint resource: resources) {
				resource.setProxy(proxy);
			}
			proxy.getEndPoints().addAll(resources);
			
			proxyRepo.save(proxy);
		}
	
	}

	@Override
	public void addProxyConsumerAssociations(List<String> proxyNames, List<String> senderApps) {
		
		List<Consumer> consumers = proxyRepo.findConsumersByName(senderApps);
		
		List<String> found = consumers.stream().map( c -> c.getConsumer_name()).collect(Collectors.toList());
		List<Proxy> proxies = proxyRepo.findProxyByName(proxyNames);
		
		consumers.forEach(c -> c.getProxies().addAll(proxies));
		proxies.forEach(p -> p.getConsumers().addAll(consumers));
	
		senderApps.removeAll(found);
		List<Consumer> newConsumers = new ArrayList<>();
		for(String c : senderApps) {
			
			Consumer consumer = new Consumer();
			consumer.setConsumer_name(c);
			newConsumers.add(consumer);
		}
		
		newConsumers.forEach(c -> c.getProxies().addAll(proxies));
		proxies.forEach(p -> p.getConsumers().addAll(newConsumers));
		
		proxyRepo.save(proxies);
	}

	@Override
	public void updateResource(List<Endpoint> resources, String proxyName) {
		
		for(Endpoint ep: resources) {
			
			List<Endpoint> endpoints = endpointRepo.getEndpoint(ep.getApi(), ep.getResource_path(), ep.getHttp_verb(), proxyName);
			if(!CollectionUtils.isEmpty(endpoints)) {
				Endpoint resource = endpoints.get(0);
				resource.setTargetPath(ep.getTargetPath());
				resource.setTargeServer(ep.getTargeServer());
				endpointRepo.save(resource);
			}
		}
	}

	@Override
	public List<Object[]> getEndpointByUri(String endpoint, String verb) {
		// TODO Auto-generated method stub
		if(endpoint.endsWith("/")) {
			endpoint = endpoint.substring(0, endpoint.lastIndexOf("/"));
		}
		if(endpoint.indexOf('?') > -1) {
			endpoint = endpoint.substring(0, endpoint.indexOf('?'));
		}
		if(endpoint.indexOf('{') > -1 && endpoint.indexOf('}') > -1) {
			endpoint = endpoint.substring(0, endpoint.indexOf('{')+1)+"%%"+endpoint.substring(endpoint.indexOf('}'));
		}
		
		List<Object[]> ep = null;
		try {
			ep = endpointRepo.getEndpointByUri(endpoint, verb);
		}catch(Exception e) {
			
		}
		
		return ep;
	}
	
	

}
