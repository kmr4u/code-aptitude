package com.anthem.microsvc.wso2greg.service;

import java.io.IOException;

import com.anthem.microsvc.wso2greg.model.Config;

public interface CodeBaseParser {

	public String parseBootstrap(String service, String profile) throws IOException;
	
	public Config findInFiles(Config config, String service, boolean checkConstants, boolean isVarCheck, boolean isNode) throws IOException;
	
	public Config parseBootstrapForMongo(Config config, String service, String profile) throws IOException;
	
	public String parseConfigJson(String service, String profile) throws IOException;
}
