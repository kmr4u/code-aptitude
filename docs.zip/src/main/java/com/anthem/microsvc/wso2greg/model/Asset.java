package com.anthem.microsvc.wso2greg.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


public class Asset {

	private String name;
	private String type;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String address;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<Asset> usedBy;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<Asset> invokes;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Asset> getUsedBy() {
		if(usedBy == null) {
			usedBy = new ArrayList<>();
		}
		return usedBy;
	}
	public List<Asset> getInvokes() {
		if(invokes == null) {
			invokes = new ArrayList<>();
		}
		return invokes;
	}
	
	
}
