/*package com.anthem.microsvc.wso2greg;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;

@Configuration
@EnableJpaRepositories(basePackages = { "com.anthem.microsvc.wso2greg.repositories" }, entityManagerFactoryRef = "ehubEntityManagerFactory", transactionManagerRef = "ehubTransactionManager")
@RefreshScope
@EnableTransactionManagement
public class EhubConfig {

	@Resource
	private Environment env;

	@Bean(name="ehubEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean ehubEntityManager(@Qualifier("ehubDataSource") DataSource ehubDataSource,EntityManagerFactoryBuilder builder){
		Map<String, Object> objMap = new HashMap<String, Object>();		
		objMap.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
		return builder.dataSource(ehubDataSource)
				.properties(objMap)
				.packages("com.anthem.microsvc.wso2greg.entities")
				.persistenceUnit("EHUB_MBR")
				.build();
				
	}


	@Bean(name="ehubDataSource")
	@ConfigurationProperties(prefix = "ehub.datasource")
	public DataSource ehubDataSource() {
		DataSource dataSource = DataSourceBuilder
		        .create()
		        .username(env.getProperty("ehub.datasource.username"))
		        .password(env.getProperty("ehub.datasource.password"))
		        .url(env.getProperty("ehub.datasource.url"))
		        .driverClassName(env.getProperty("ehub.datasource.driverClassName"))		        
		        .build();
		return dataSource;
	}

	@Bean(name = "ehubTransactionManager")
	public PlatformTransactionManager transactionManager(
			@Qualifier("ehubEntityManagerFactory") EntityManagerFactory emf) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(emf);
		return transactionManager;
	}

}*/