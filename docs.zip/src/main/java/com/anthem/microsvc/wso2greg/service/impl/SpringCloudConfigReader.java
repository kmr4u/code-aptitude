package com.anthem.microsvc.wso2greg.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.anthem.microsvc.wso2greg.constants.Constants;
import com.anthem.microsvc.wso2greg.model.Config;
import com.anthem.microsvc.wso2greg.service.ConfigSourceReader;
import com.anthem.microsvc.wso2greg.service.HTTPSenderService;

@Component
public class SpringCloudConfigReader implements ConfigSourceReader {

	@Autowired
	private HTTPSenderService sender;
	@Override
	public Config readConfigProps(String uri,  Map<String, String> headers, boolean isNode) throws IOException {
		
		Config config = new Config();
		String resp = null;
		if(isNode){
			uri = uri.substring(0, uri.indexOf(".json")) + ".properties";
		}
		resp = sender.invokeGET(uri, null, true, false);

		Properties appProps = new Properties();
		appProps.load(new ByteArrayInputStream(resp.getBytes()));
		// System.out.println(appProps);

		Set<Map.Entry<Object, Object>> propsSet = appProps.entrySet();
		//String serviceFolder = WSO2Utility.getFolderPath() + serviceName;

		propsSet.forEach(entry -> {
			config.getProperties().put(entry.getKey().toString(), entry.getValue());
			Constants.KEYS.forEach(key -> {
				if(entry.getKey().toString().contains(key)){
					config.getKeys().add(entry.getKey().toString());
			}
			});
		});
		
		return config;
	}

}
