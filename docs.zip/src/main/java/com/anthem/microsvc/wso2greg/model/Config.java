package com.anthem.microsvc.wso2greg.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "uri"
})
public class Config {

    @JsonProperty("uri")
    private String uri;
    @JsonIgnore
    private Map<String, Object> properties = new HashMap<String, Object>();

    private Set<String> keys;
    
    @JsonProperty("uri")
    public String getUri() {
        return uri;
    }

    @JsonProperty("uri")
    public void setUri(String uri) {
        this.uri = uri;
    }

    @JsonAnyGetter
    public Map<String, Object> getProperties() {
    	
    	if(null == properties) {
    		this.properties = new HashMap<>();
    	} 
    	return this.properties;
    }

    @JsonAnySetter
    public void setProperty(String name, Object value) {
        this.properties.put(name, value);
    }

	public Set<String> getKeys() {
		if(null == this.keys) {
			this.keys = new HashSet<>();
		}
		return keys;
	}

}
