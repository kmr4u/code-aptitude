package com.anthem.microsvc.wso2greg.model;

public class Resource {

	private String flowName;
	private String verb;
	private String proxyPathSuffix;
	private String targetServer;
	private String targetPathSuffix;
	private boolean targetCopyPathSuffix;
	
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public String getVerb() {
		return verb;
	}
	public void setVerb(String verb) {
		this.verb = verb;
	}
	public String getProxyPathSuffix() {
		return proxyPathSuffix;
	}
	public void setProxyPathSuffix(String proxyPathSuffix) {
		this.proxyPathSuffix = proxyPathSuffix;
	}
	public String getTargetServer() {
		return targetServer;
	}
	public void setTargetServer(String targetServer) {
		this.targetServer = targetServer;
	}
	public String getTargetPathSuffix() {
		return targetPathSuffix;
	}
	public void setTargetPathSuffix(String targetPathSuffix) {
		this.targetPathSuffix = targetPathSuffix;
	}
	public boolean isTargetCopyPathSuffix() {
		return targetCopyPathSuffix;
	}
	public void setTargetCopyPathSuffix(boolean targetCopyPathSuffix) {
		this.targetCopyPathSuffix = targetCopyPathSuffix;
	}
	
}
