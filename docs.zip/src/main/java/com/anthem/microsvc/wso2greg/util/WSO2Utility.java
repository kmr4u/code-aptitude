package com.anthem.microsvc.wso2greg.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

import com.anthem.microsvc.wso2greg.constants.Constants;
import com.anthem.microsvc.wso2greg.entities.Consumer;
import com.anthem.microsvc.wso2greg.entities.Endpoint;
import com.anthem.microsvc.wso2greg.entities.MsInventory;
import com.anthem.microsvc.wso2greg.entities.Proxy;
import com.anthem.microsvc.wso2greg.model.HttpResponse;


public class WSO2Utility {
	
	private final static Logger LOGGER = Logger.getLogger(WSO2Utility.class.getName());
	private static final Random random = new Random();
	
	static {
		HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> hostname.equals("ipaddress"));
	}

	// method for deleting folders and files.
	private static boolean deleteDirectory(File dir) {
		if (dir.isDirectory()) {
			File[] children = dir.listFiles();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDirectory(children[i]);
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}

	// cloning repository.
	public static Git cloneRepository(String repoUrl, String directoryPath, String userName, String password)
			throws Exception {
		Git git = null;
		try {
			git = Git.cloneRepository().setURI(repoUrl).setDirectory(Paths.get(directoryPath).toFile())
					.setCredentialsProvider(getUserCredentials(userName, password)).call();
		} catch (InvalidRemoteException | TransportException e) {
			throw e;
		} catch (GitAPIException e) {
			throw e;
		}
		return git;
	}

	// method for passing user credentials for cloning repo.
	public static CredentialsProvider getUserCredentials(String userName, String password) {
		UsernamePasswordCredentialsProvider credentials = new UsernamePasswordCredentialsProvider(userName, password);
		return credentials;
	}

	public static String getFolderPath() {
		return System.getProperty(Constants.USER_DIR) + "\\";
	}

	public static String getHttpResponse(String urlStr) throws IOException {
		String response = "";
		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };

			// Install the all-trusting trust manager
			try {
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			} catch (Exception e) {
			}

			URL url = new URL(urlStr);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			// conn.setRequestProperty("Accept", "application/json");
			// conn.setRequestProperty("Authorization", auth);
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode() + urlStr);
			}
			/*
			 * BufferedReader br = new BufferedReader(new InputStreamReader(
			 * (conn.getInputStream()))); String output; while ((output =
			 * br.readLine()) != null) { response += output; }
			 */
			response = readFully(conn.getInputStream()).toString(Constants.ENCODING_UTF8);
			conn.disconnect();
			LOGGER.info("Spring Cloud Config Server Endpoint called: " + urlStr);
		} catch (MalformedURLException e) {
			LOGGER.info("There was an error invoking Spring Cloud Config Server Endpoint: " + urlStr);
			throw e;
		} catch (IOException e) {
			LOGGER.info("There was an error invoking Spring Cloud Config Server Endpoint: " + urlStr);
			throw e;
		}
		return response;

	}

	private static ByteArrayOutputStream readFully(InputStream inputStream) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int length = 0;
		while ((length = inputStream.read(buffer)) != -1) {
			baos.write(buffer, 0, length);
		}
		return baos;
	}

	public static String createDomainRequestBody(String domain) throws Exception {
		JSONObject request = new JSONObject();
		try {
			request.put("name", domain);
			request.put("version", 1);
			request.put("type", "domains");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
	}

	public static String createServiceRequestBody(String serviceName, String contextRoot) throws Exception {
		JSONObject request = new JSONObject();
		try {
			request.put("name", serviceName);
			request.put("version", 1);
			request.put("type", "restservices");
			request.put("context", contextRoot);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
	}
	

	public static String createAPIGEERequestBody(String proxyName, String basePath) throws Exception {
		JSONObject request = new JSONObject();
		try {
			request.put("name", proxyName);
			request.put("version", 1);
			request.put("type", "apiproxy");
			request.put("basePath", basePath);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
	}
	
	public static String createConsumersRequestBody(String consumerName) throws Exception {
		JSONObject request = new JSONObject();
		try {
			request.put("name", consumerName);
			request.put("version", 1);
			request.put("type", "apiconsumer");

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
	}
	
	public static String createSDSMicroSDSRequestBody(String name, String address, boolean isSDS) throws Exception {
		JSONObject request = new JSONObject();
		try {
			request.put("name", name);
			request.put("address", address);
			request.put("version", 1);
			if(isSDS) {
				request.put("type", "ehubsds");
			} else {
				request.put("type", "microsds");
			}
			request.put("environment", "Test");


		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
	}
	public static String createAddResourceBody(String project, String service, String env) {
		JSONObject request = new JSONObject();
		try {
			request.put("project", project);
			request.put("servicenm", service);
			request.put("profile", env);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
		
	}
	public static String createAssociationPathService(String serviceName) throws Exception {
		String path = "?path=" + Constants.REST_ASSOCIATION_PATH + serviceName;

		return path;
	}
	
	public static String createAssociationPathAPIProxy(String proxyName){
		String path = "?path=" + Constants.REST_ASSOCIATION_PROXY + proxyName;

		return path;
	}
	
	public static String createAssociationPathServiceToDomainRequestBody(String domainName) throws Exception {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", "ownedby");
			request.put("target", Constants.REST_DOMAINS_PATH + domainName);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	
	public static String createAssociationPathSDSMicroSDS(String dbName, boolean isSDS) throws Exception {
		
		if(isSDS) {
			return "?path=" + Constants.SDS_PATH + dbName;
		}
		return "?path=" + Constants.MICROSDS_PATH + dbName;	
	}
	
	public static String createAssociationPathEndpoint(String resource, String endpoint) throws Exception {
		
		endpoint = endpoint.replaceAll("/\\{", "/\\$").replaceAll("\\}/", "/").replaceAll("\\*", "\\$").replaceAll("/", ".");
		if(endpoint.indexOf("}")>-1) {
			endpoint = endpoint.substring(0, endpoint.indexOf("}"));
		}
		String[] arr = endpoint.split("\\.");
		StringBuilder location= new StringBuilder("");
		for(int i=arr.length-2; i>=0; i--) {
			if(StringUtils.hasText(arr[i])) {
				location.append(arr[i]).append(".");
			}
		}
		endpoint = location.substring(0, location.length()-1);
		endpoint = endpoint.replaceAll("-", "_").toLowerCase();
		location = new StringBuilder(endpoint);
		location.append("-"+arr[arr.length-1]).append("-"+resource);
		
		String path = "?path=" + Constants.REST_ASSOCIATION_ENDPOINT + "ep-" + location;
		return path;
			
	}
	public static String createAssociationPathServiceToSDSRequestBody(String dbName, boolean isSDS) throws Exception {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", "depends");
			if(isSDS) {
				request.put("target", Constants.SDS_PATH + dbName);
			} else {
				request.put("target", Constants.MICROSDS_PATH + dbName);
			}


		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	public static String createAssociationPathSDSToServiceRequestBody(String service) throws Exception {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", "usedBy");
			
				request.put("target", Constants.REST_ASSOCIATION_PATH + service);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	
	public static String createAssociationPathConsumerRequestBody(Iterable<String> consumers) throws Exception {
		JSONArray jsonArray = new JSONArray();
		for(String consumer: consumers) {
			JSONObject request = new JSONObject();
			try {
				request.put("type", "usedBy");
				request.put("target", Constants.REST_ASSOCIATION_CONSUMER + consumer);

			} catch (JSONException e) {
				e.printStackTrace();
			}
			jsonArray.put(request);
		}
		
		return jsonArray.toString();
	}
	
	public static String createAssociationPathAPIGEEProxyRequestBody(String apiProyName) throws Exception {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", "usedBy");
			request.put("target", Constants.REST_ASSOCIATION_PROXY + apiProyName);
			


		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	
	public static String createAssociationEndpointsAPIGEEProxyRequestBody(String resource, String endpoint) throws Exception {

		endpoint = endpoint.replaceAll("/\\{", "/\\$").replaceAll("\\}/", "/").replaceAll("/", ".");
		String[] arr = endpoint.split("\\.");
		StringBuilder location= new StringBuilder("");
		for(int i=arr.length-2; i>=0; i--) {
			location.append(arr[i]).append(".");
		}
		endpoint = location.substring(0, location.length()-1);
		location = new StringBuilder(endpoint);
		location.append("-"+arr[arr.length-1]).append("-"+resource);
		
		JSONObject request = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		try {
			request.put("type", "usedBy");
			request.put("target", Constants.REST_ASSOCIATION_ENDPOINT+location);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	
	public static String createEndpointRequestBody(String resourceName, String endpoint) throws Exception {

		endpoint = endpoint.replaceAll("/\\{", "/\\$").replaceAll("\\}/", "/").replaceAll("\\*", "\\$");
		if(endpoint.indexOf("}")>-1) {
			endpoint = endpoint.substring(0, endpoint.indexOf("}"));
		}
		JSONObject request = new JSONObject();
		try {
			request.put("name", resourceName);
			request.put("type", "endpoint");
			request.put("address", endpoint);
			request.put("version", "v1");
			//request.put("environment", "Test");
			


		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
	}

	public static String createSouthiboundAssociationPathAPIGEEProxyRequestBody(String apiProyName) throws Exception {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", "depends");
			request.put("target", Constants.REST_ASSOCIATION_PROXY + apiProyName);
			


		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	
	public static String createServiceToEndpointAssociationBody(String resource, String endpoint) {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		endpoint = endpoint.replaceAll("/\\{", "/\\$").replaceAll("\\}/", "/").replaceAll("/", ".");
		String[] arr = endpoint.split("\\.");
		StringBuilder location= new StringBuilder("");
		for(int i=arr.length-2; i>=0; i--) {
			location.append(arr[i]).append(".");
		}
		endpoint = location.substring(0, location.length()-1);
		location = new StringBuilder(endpoint);
		location.append("-"+arr[arr.length-1]).append("-"+resource);
		try {
			request.put("type", "depends");
			request.put("target", Constants.REST_ASSOCIATION_ENDPOINT+ location);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	public static String createEndpointToServiceAssociationBody(String service, boolean isOutBound) {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", isOutBound ? "usedBy": "depends");
			request.put("target", Constants.REST_ASSOCIATION_PATH+ service);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	public static String createSouthBoundServiceToEndpointAssociationBody(String target) {
		JSONArray jsonArray = new JSONArray();
		JSONObject request = new JSONObject();
		try {
			request.put("type", "depends");
			request.put("target", target);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		jsonArray.put(request);
		return jsonArray.toString();
	}
	public static String getServiceContext(String serviceName) {
		String contextName = "";

		String csvFile = "C:\\Users\\AG17412\\Documents\\WSO2POC\\sit_services.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {

			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] services = line.split(cvsSplitBy);

				if (services.length > 1 && services[0].equals(serviceName)) {
					contextName = services[1];
				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return contextName;
	}
	
	/*public static List<ApiProxy> getAPIGEEProxy(String csvFile) {
		List<ApiProxy> apigeeProxies = new ArrayList<>();
		
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] services = line.split(cvsSplitBy);
				try {
					
					ApiProxy apiProxy = new ApiProxy();
					apiProxy.setProxy(services[0]);
					apiProxy.setApi(services[1]);
					apiProxy.setHttpMethod(services[2]);
					apiProxy.setBasePath(services[3]);
					
					if(services.length >= 5 && services.length <= 8) {
						apiProxy.setResourcePath(services[4]);
						apiProxy.setTargetHost(services[5]);
						apiProxy.setTargetPath(services[6]);
						if(services.length == 8) {
							apiProxy.setConsumers(services[7]);
						}
					}
					
					apigeeProxies.add(apiProxy);
					
				} catch (Exception e) {
					LOGGER.info("Error while adding row: "+line);
				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return apigeeProxies;
	}*/
	
	public static List<MsInventory> getMsContextRoots(String csvFile) {
		List<MsInventory> services = new ArrayList<>();
		
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {

			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] service = line.split(cvsSplitBy);
				try {
					//LOGGER.info(line);

					MsInventory ms = new MsInventory();
					ms.setService(service[0]);
					ms.setContextRoot(service[1]);
					
					services.add(ms);
				
				} catch (Exception e) {
					LOGGER.info("Error while adding row: "+line);
				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		return services;
	}
	public static Set<Proxy> getApiProxies(String csvFile) {
		
		Set<Proxy> proxies = new HashSet<>();
		//Set<Consumer> consumers = new HashSet<>();
		
		Map<String, Consumer> uniqConsumers = new HashMap<>();
		Map<String, Proxy> uniqProxies = new HashMap<>();
		
		
		//String csvFile = "C:\\Users\\AG17412\\Documents\\WSO2POC\\Apigee_uat_01_25_2020.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {

			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] services = line.split(cvsSplitBy);
				try {
					String proxyName = services[0];
					if(!uniqProxies.containsKey(proxyName)) {
						
						Proxy proxy = new Proxy();
						
						proxy.setProxy(proxyName);
						proxy.setBasePath(services[3]);
						
						uniqProxies.put(proxyName, proxy);
						
						Endpoint ep = new Endpoint();
						
						ep.setApi(services[1]);
						ep.setHttp_verb(services[2]);
						ep.setResource_path(services[4]);
						if(services.length <= 8) {
							ep.setTargeServer(services[5]);
							ep.setTargetPath(services[6]);
						}
						
						if(services.length == 8) {
							Set<String> consumers = getConsumers(services[7]);
							for(String val: consumers) {
								if(!uniqConsumers.containsKey(val)) {
									
									Consumer consumer = new Consumer();
									consumer.setConsumer_name(val);
									
									uniqConsumers.put(val, consumer);
									consumer.getProxies().add(proxy);
									
									proxy.getConsumers().add(consumer);
								}else {
									
									proxy.getConsumers().add(uniqConsumers.get(val));
									uniqConsumers.get(val).getProxies().add(proxy);
									
								}
								
							}
						}
						ep.setProxy(proxy);
						
						proxy.getEndPoints().add(ep);
						
						proxies.add(proxy);
					}else {
						
						Endpoint ep = new Endpoint();
												
						ep.setApi(services[1]);
						ep.setHttp_verb(services[2]);
						ep.setResource_path(services[4]);
						if(services.length <= 8) {
							ep.setTargeServer(services[5]);
							ep.setTargetPath(services[6]);
						}
						
						ep.setProxy(uniqProxies.get(proxyName));
						uniqProxies.get(proxyName).getEndPoints().add(ep);
					}
					
				} catch (Exception e) {
					LOGGER.info("Error while adding row: "+line);
				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return proxies;
	}

	public static HttpResponse getHttpResponse(String httpUrl, String auth, String verb, String requestBody,
			String apikey) throws Exception {

		HttpResponse httpResponse = new HttpResponse();
		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };

			// Install the all-trusting trust manager
			try {
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			} catch (Exception e) {
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				httpResponse.setResponse(sw.toString());
			}

			URL url = new URL(httpUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod(verb);
			conn.setRequestProperty("Accept", "application/json");
			if (auth != null) {
				conn.setRequestProperty("Authorization", auth);
			}

			if (apikey != null) {
				conn.setRequestProperty("apikey", apikey);
			}
			if (!verb.equalsIgnoreCase("GET")) {
				
				if (httpUrl.contains("bamboo.anthem.com")) {
					conn.setRequestProperty("X-Atlassian-Token", "no-check");
				}
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setRequestProperty("Content-Type", "application/json");
				if (requestBody != null) {
					OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
					wr.write(requestBody);
					wr.flush();
				}

			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int length = 0;
			if (conn.getResponseCode() != 200 && conn.getResponseCode() != 201 && conn.getResponseCode() != 204) {			
				httpResponse.setStatusCode(HttpStatus.valueOf(conn.getResponseCode()));
				while ((length = conn.getErrorStream().read(buffer)) != -1) {
					baos.write(buffer, 0, length);
				}
				httpResponse.setResponse(baos.toString("utf-8"));
			} else {
				httpResponse.setLocation(conn.getHeaderField("Location"));
				httpResponse.setStatusCode(HttpStatus.valueOf(conn.getResponseCode()));
				httpResponse.setMessage(conn.getResponseMessage());
				while ((length = conn.getInputStream().read(buffer)) != -1) {
					baos.write(buffer, 0, length);
				}
				httpResponse.setResponse(baos.toString("utf-8"));
			}
			conn.disconnect();
			
			if(!verb.equals("GET") && !verb.equals("DELETE")) {
				LOGGER.info("Asset created/associated : " + httpUrl);
				LOGGER.info(requestBody);
				LOGGER.info("------------------- \n");
			}

			
		} catch (MalformedURLException e) {
			LOGGER.info("Error in creating asset : " + httpUrl);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			httpResponse.setResponse(sw.toString());

			// e.printStackTrace();
		} catch (IOException e) {
			LOGGER.info("Error in creating asset : " + httpUrl);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			httpResponse.setResponse(sw.toString());

			// e.printStackTrace();
		} catch (Exception e) {
			LOGGER.info("Error in creating asset : " + httpUrl);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			httpResponse.setResponse(sw.toString());

			// e.printStackTrace();
		}

		return httpResponse;

	}
	
	public static String getScmCloneUrl(String usernm, String project, String service) {
		
		return "https://"+usernm+"@bitbucket.anthem.com/scm/" + project + "/" + service + ".git";
	}
	
	public static boolean deleteDir(String serviceName) {
		File dir = new File(WSO2Utility.getFolderPath() + serviceName);
		if (dir.isDirectory()) {
			File[] children = dir.listFiles();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDirectory(children[i]);
				if (!success) {
					return false;
				}
			}
		}
		return dir.delete();
	}
	
	public static String generateRandomHost(int num) {
		switch (num) {
		case 0: return "http://localhost:8081";
		case 1: return "http://localhost:8082";
		case 2: return "http://localhost:8083";
		default: return "http://localhost:8080";
		}
	}
	
	
	private static Set<String> getConsumers(String str){
		
		return new HashSet<String>(Arrays.asList(str.split(";")));
	}
}
