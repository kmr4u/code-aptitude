package com.anthem.microsvc.wso2greg.service;

import java.util.Map;

import org.springframework.http.HttpMethod;

public interface HTTPSenderService {

	public String invokeGET(String uri, Map<String, String> headers, boolean isConfig, boolean isDelete);
	
	public String sendPayLoad(String uri, HttpMethod method, String reqBody, Map<String, String> headers);
	
}
