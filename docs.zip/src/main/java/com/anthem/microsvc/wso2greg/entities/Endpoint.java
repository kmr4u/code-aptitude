package com.anthem.microsvc.wso2greg.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "endpoint", schema = "inventory")
//@IdClass(EndpointKey.class)
public class Endpoint implements Serializable{
	
	private int id;
	private String api; 
	private String http_verb;
	private String resource_path; 
	private String targeServer; 
	private String targetPath;
	
	private Proxy proxy;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name="api")
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	
	@Column(name="http_verb")
	public String getHttp_verb() {
		return http_verb;
	}
	public void setHttp_verb(String http_verb) {
		this.http_verb = http_verb;
	}
	
	@Column(name="resource_path")
	public String getResource_path() {
		return resource_path;
	}
	public void setResource_path(String resource_path) {
		this.resource_path = resource_path;
	}
	
	@Column(name="target_server")
	public String getTargeServer() {
		return targeServer;
	}
	public void setTargeServer(String targeServer) {
		this.targeServer = targeServer;
	}
	
	@Column(name="target_path")
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fk_proxy_id")
	public Proxy getProxy() {
		return proxy;
	}
	public void setProxy(Proxy proxy) {
		this.proxy = proxy;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((api == null) ? 0 : api.hashCode());
		result = prime * result + ((http_verb == null) ? 0 : http_verb.hashCode());
		result = prime * result + id;
		result = prime * result + ((proxy == null) ? 0 : proxy.hashCode());
		result = prime * result + ((resource_path == null) ? 0 : resource_path.hashCode());
		result = prime * result + ((targeServer == null) ? 0 : targeServer.hashCode());
		result = prime * result + ((targetPath == null) ? 0 : targetPath.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Endpoint other = (Endpoint) obj;
		if (api == null) {
			if (other.api != null)
				return false;
		} else if (!api.equals(other.api))
			return false;
		if (http_verb == null) {
			if (other.http_verb != null)
				return false;
		} else if (!http_verb.equals(other.http_verb))
			return false;
		if (id != other.id)
			return false;
		if (proxy == null) {
			if (other.proxy != null)
				return false;
		} else if (!proxy.equals(other.proxy))
			return false;
		if (resource_path == null) {
			if (other.resource_path != null)
				return false;
		} else if (!resource_path.equals(other.resource_path))
			return false;
		if (targeServer == null) {
			if (other.targeServer != null)
				return false;
		} else if (!targeServer.equals(other.targeServer))
			return false;
		if (targetPath == null) {
			if (other.targetPath != null)
				return false;
		} else if (!targetPath.equals(other.targetPath))
			return false;
		return true;
	}

	
}