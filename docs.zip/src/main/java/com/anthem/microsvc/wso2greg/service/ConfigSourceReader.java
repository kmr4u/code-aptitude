package com.anthem.microsvc.wso2greg.service;

import java.io.IOException;
import java.util.Map;

import com.anthem.microsvc.wso2greg.model.Config;

public interface ConfigSourceReader {

	public Config readConfigProps(String uri,  Map<String, String> headers, boolean isNode) throws IOException;
}
