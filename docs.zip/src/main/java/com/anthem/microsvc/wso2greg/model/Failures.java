package com.anthem.microsvc.wso2greg.model;

import java.util.ArrayList;
import java.util.List;

public class Failures {

	private List<String> contextRootMissing;
	private List<String> failed;
	
	public List<String> getContextRootMissing() {
		if(contextRootMissing == null) {
			contextRootMissing = new ArrayList<String>();
		}
		return contextRootMissing;
	}
	
	public List<String> getFailed() {
		if(failed == null) {
			failed = new ArrayList<>();
		}
		return failed;
	}
	
}
