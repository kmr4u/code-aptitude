package com.anthem.microsvc.wso2greg;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(/*prefix = "wso2"*/)
public class WSO2ConfigProps {

	private Map<String, String> wso2;

	public Map<String, String> getWso2() {
		return wso2;
	}

	public void setWso2(Map<String, String> wso2) {
		this.wso2 = wso2;
	}
	
}
