package com.anthem.microsvc.wso2greg.repositories;

import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.microsvc.wso2greg.entities.ApiProxy;
import com.anthem.microsvc.wso2greg.entities.MsInventory;


@Repository
public interface GovRegRepositoryService extends
		CrudRepository<ApiProxy, String> {
	
	/*@Transactional
	@Query("select a from ApiProxy a where a.targetPath LIKE %:context% group by a.basePath, a.resourcePath")
	public List<ApiProxy> getApigeeProxies(@Param(value = "context") String contextRoot);*/
	
	/*@Transactional
	@Query("select a from ApiProxy a where CONCAT(a.basePath, '', a.resourcePath) LIKE %:endpoint% group by a.proxy")
	public List<ApiProxy> getApiProxies(@Param(value = "endpoint") String endpoint);*/
	
	/*@Transactional
	@Query("select distinct a.proxy, a.basePath from ApiProxy a")
	public List<Object[]> getAllProxies();*/
	
	/*@Transactional
	@Query("select distinct a.proxy, a.consumers from ApiProxy a")
	public List<Object[]> getAllConsumers();*/
	
	
	/*@Transactional
	@Query("select a from ApiProxy a where a.basePath = :endpoint group by a.proxy")
	public List<ApiProxy> getProxyFromBasePath(@Param(value = "endpoint") String endPoint);*/
	
	
	/*@Transactional
	@Query("select distinct a.proxy, a.api, a.basePath, a.resourcePath from ApiProxy a")
	public List<Object[]> getAllEndpoints();*/
}
