package com.anthem.microsvc.wso2greg;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "failures")
public class ServiceConfigUrlProps {

	private Map<String, String> soadmbr;
	private Map<String, String> soadutl;
	private Map<String, String> nexgeneng;
	private Map<String, String> soadpdt;
	private Map<String, String> soadclm;
	
	public Map<String, String> getSoadmbr() {
		return soadmbr;
	}
	public void setSoadmbr(Map<String, String> soadmbr) {
		this.soadmbr = soadmbr;
	}
	public Map<String, String> getSoadutl() {
		return soadutl;
	}
	public void setSoadutl(Map<String, String> soadutl) {
		this.soadutl = soadutl;
	}
	public Map<String, String> getNexgeneng() {
		return nexgeneng;
	}
	public void setNexgeneng(Map<String, String> nexgeneng) {
		this.nexgeneng = nexgeneng;
	}
	public Map<String, String> getSoadpdt() {
		return soadpdt;
	}
	public void setSoadpdt(Map<String, String> soadpdt) {
		this.soadpdt = soadpdt;
	}
	
	public Map<String, String> getSoadclm() {
		return soadclm;
	}
	public void setSoadclm(Map<String, String> soadclm) {
		this.soadclm = soadclm;
	}
	
	public Map<String, String> getConfigUrlMap(String domain){
		switch (domain){
			case "SOADMBR":
				return getSoadmbr();
			case "SOADUTL":
				return getSoadutl();
			case "SOADPDT":
				return getSoadpdt();
			case "NEXGENENG":
				return getNexgeneng();
			case "SOADCLM":
				return getSoadclm();
		}
		
		return null;
	}
}
