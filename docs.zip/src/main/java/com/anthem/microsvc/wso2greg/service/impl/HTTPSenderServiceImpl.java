package com.anthem.microsvc.wso2greg.service.impl;

import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.microsvc.wso2greg.service.HTTPSenderService;

@Component
public class HTTPSenderServiceImpl implements HTTPSenderService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${wso2.creds}")
	private String creds;

	@Override
	public String invokeGET(String uri, Map<String, String> headers, boolean isConfig, boolean isDelete) {
		String resp = null;
		ResponseEntity<String> restResp = null;
		
		HttpHeaders reqHeaders = new HttpHeaders();
		//reqHeaders.add(key, value)
		if(!isConfig) {
			if(!MapUtils.isEmpty(headers) && null != headers.get("Authorization")) {
				reqHeaders.add("Authorization", headers.get("Authorization"));
			}else {
				reqHeaders.add("Authorization", creds);
			}
		}
		
		try {
			UriComponents uriComponents = UriComponentsBuilder
					.fromHttpUrl(uri).build();
			HttpEntity<String> requestEntity = new HttpEntity<String>(reqHeaders);
			
			restResp = restTemplate.exchange(uriComponents.encode().toUri(), !isDelete ? HttpMethod.GET : HttpMethod.DELETE, requestEntity,	String.class);
		}catch(Exception e) {
			return resp;
		}
		
		if(restResp != null && restResp.getStatusCode().is2xxSuccessful()) {
			return restResp.getBody();
		}
		return resp;
	}

	@Override
	public String sendPayLoad(String uri, HttpMethod method, String reqBody, Map<String, String> headers) {
		String resp = null;
		ResponseEntity<String> restResp = null;
		HttpHeaders reqHeaders = new HttpHeaders();
		if(!MapUtils.isEmpty(headers) && headers.containsKey("Authorization")) {
			reqHeaders.add("Authorization", headers.get("Authorization"));
		}else {
			reqHeaders.add("Authorization", creds);
		}
		reqHeaders.setContentType(MediaType.APPLICATION_JSON);
		//reqHeaders.add("apikey", null);
		
		try {       
			UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(uri).build();
			HttpEntity<String> requestEntity = new HttpEntity<>(reqBody, reqHeaders);
			
			restResp = restTemplate.exchange(uriComponents.encode().toUri(), method, requestEntity, String.class);
			//httpResp = WSO2Utility.getHttpResponse(uri,  Constants.WSO2_CREDS, method.toString(), reqBody, null);
		}catch(Exception e) {
			throw e;
		}
		
		if(restResp != null && restResp.getStatusCode().is2xxSuccessful()) {
			if(StringUtils.hasText(restResp.getBody()))
				return restResp.getBody().toString();
			else {
				return "Success";
			}
		}
		/*if(httpResp != null && httpResp.getStatusCode().is2xxSuccessful()) {
			return httpResp.getLocation();
		}*/
		return resp;
	}

}
