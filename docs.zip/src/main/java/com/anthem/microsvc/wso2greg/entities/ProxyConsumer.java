package com.anthem.microsvc.wso2greg.entities;

public class ProxyConsumer {

}
