package com.anthem.microsvc.wso2greg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ms_registry", schema = "inventory")
public class MsInventory implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1482719141648006011L;
	/**
	 * 
	 */
	private String service;
	private String contextRoot;
	
	@Id
	@Column(name="service")
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	@Column(name="context_root")
	public String getContextRoot() {
		return contextRoot;
	}
	public void setContextRoot(String contextRoot) {
		this.contextRoot = contextRoot;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contextRoot == null) ? 0 : contextRoot.hashCode());
		result = prime * result + ((service == null) ? 0 : service.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MsInventory other = (MsInventory) obj;
		if (contextRoot == null) {
			if (other.contextRoot != null)
				return false;
		} else if (!contextRoot.equals(other.contextRoot))
			return false;
		if (service == null) {
			if (other.service != null)
				return false;
		} else if (!service.equals(other.service))
			return false;
		return true;
	}
	
	
}
