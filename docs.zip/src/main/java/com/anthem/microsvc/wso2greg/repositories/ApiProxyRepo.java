package com.anthem.microsvc.wso2greg.repositories;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.microsvc.wso2greg.entities.Consumer;
import com.anthem.microsvc.wso2greg.entities.Proxy;

@Repository
@Transactional
public interface ApiProxyRepo extends CrudRepository<Proxy, Serializable>{

	@Transactional
	@Query("select a.proxy, a.basePath from Proxy a")
	public List<Object[]> getAllProxies();
	
	@Transactional
	@Query("select a from Proxy a JOIN a.consumers b")
	public List<Proxy> getAllProxyConsumers();
	
	@Transactional
	@Query("select a.proxy, b.api, a.basePath, b.resource_path from Proxy a JOIN a.endPoints b")
	public List<Object[]> getAllEndpoints();
	
	@Transactional
	@Query("select a from Proxy a JOIN FETCH a.endPoints b where CONCAT(a.basePath, '', b.resource_path) LIKE %:endpoint% group by a.proxy")
	public List<Proxy> getApiProxiesFromEndpoint(@Param(value = "endpoint") String endpoint);
	
	@Transactional
	@Query("select a from Proxy a where a.basePath = :endpoint group by a.proxy")
	public List<Proxy> getProxyFromBasePath(@Param(value = "endpoint") String endPoint);
	
	@Transactional
	@Query("select a from Proxy a JOIN FETCH a.endPoints b where b.targetPath LIKE %:context% group by a.basePath, b.resource_path")
	public List<Proxy> getApigeeProxiesFromContextRoot(@Param(value = "context") String contextRoot);
	
	@Transactional
	@Query("select a from Proxy a where a.proxy = :proxy")
	public List<Proxy> findProxyByName(@Param(value = "proxy") String proxyName);
	
	@Transactional
	@Query("select a from Consumer a where a.consumer_name in :consumers")
	public List<Consumer> findConsumersByName(@Param(value = "consumers") List<String> senderApps);
	
	@Transactional
	@Query("select a from Proxy a where a.proxy in :proxies")
	public List<Proxy> findProxyByName(@Param(value = "proxies") List<String> proxyNames);
	
	@Transactional
	@Query("select a from Proxy a where a.proxy in :proxies")
	public List<Proxy> updateResource(@Param(value = "proxies") List<String> proxyNames);
}
