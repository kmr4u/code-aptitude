package com.anthem.microsvc.wso2greg.repositories;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.anthem.microsvc.wso2greg.entities.Endpoint;


@Repository
@Transactional
public interface EndpointRepository extends CrudRepository<Endpoint, Serializable>{

	@Query("select a from Endpoint a JOIN a.proxy b where a.api=:api and a.resource_path=:path and a.http_verb = :verb and b.proxy=:proxy")
	public List<Endpoint> getEndpoint(@Param(value = "api") String api, @Param(value = "path") String resourcePath, @Param(value = "verb") String verb, @Param(value = "proxy") String proxy);
	
	
	@Query("select a.api, a.resource_path from Endpoint a JOIN a.proxy b where CONCAT(b.basePath, a.resource_path) LIKE %:uri% and a.http_verb = :verb")
	public List<Object[]> getEndpointByUri(@Param(value="uri") String uri, @Param(value="verb") String verb);
}
