package com.anthem.microsvc.wso2greg.service;

import java.util.List;

import com.anthem.microsvc.wso2greg.entities.ApiProxy;
import com.anthem.microsvc.wso2greg.entities.Endpoint;
import com.anthem.microsvc.wso2greg.entities.Proxy;

public interface WSO2AdapterService {

	public boolean addService(String serviceName, String contextRoot) throws Exception;
	
	public void addServiceToDomainAssociation(String serviceName, String domain) throws Exception;
	
	public void addServiceToSDSAssociation(String serviceName, String dbName, String address, boolean isSDS) throws Exception;
	
	public void addApigeeProxyConsumers(String serviceName) throws Exception;
	
	public void addServiceToAPIGEEAssociation(String serviceName, Proxy proxy) throws Exception;
	
	public void addEndpointsToAPIGEEAssociation(String proxyName, String api, String endpoint) throws Exception;
	
	public void addSouthboundServiceToEndpointAssociation(String serviceName, String basePath, List<Endpoint> eps) throws Exception;
	
	public void addSouthiboundServiceToAPIGEEAssociation(String serviceName, Proxy proxy) throws Exception;
	
	public void addServiceToEndPointAssociation(String serviceName, String basePath, List<Endpoint> proxy) throws Exception;
	
	public void addResourceProxy(String name, String basePath) throws Exception;
	
	public void addProxyToConsumerAssociation(String proxy, Iterable<String> consumers) throws Exception;
	
	public void addResourceConsumer(String consumer) throws Exception;
	
	public String getAllAssets(String resourceName) throws Exception;
	
	public String getAllAssociations(String path) throws Exception;
	
	public String getAllSDSAssociations(String type, String asset) throws Exception;
	
	public String getAssetByName(String name, String type) throws Exception;
	
	public void addSouthboundServiceToEndpointAssociation(String serviceName, String endpoint) throws Exception;
}
