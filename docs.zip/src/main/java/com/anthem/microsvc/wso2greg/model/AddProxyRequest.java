package com.anthem.microsvc.wso2greg.model;

public class AddProxyRequest {
	
	private String proxyName;
	private String basePath;
	
	
	public String getProxyName() {
		return proxyName;
	}
	public void setProxyName(String proxyName) {
		this.proxyName = proxyName;
	}
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}
}
