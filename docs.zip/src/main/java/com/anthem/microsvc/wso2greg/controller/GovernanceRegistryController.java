package com.anthem.microsvc.wso2greg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.anthem.emep.common.exception.helper.ExceptionObjFactory;
import com.anthem.microsvc.wso2greg.model.AddAllAssetsRequest;
import com.anthem.microsvc.wso2greg.model.AddAssetRequest;
import com.anthem.microsvc.wso2greg.model.AddAssetResponse;
import com.anthem.microsvc.wso2greg.model.AddConsumerAssociationRequest;
import com.anthem.microsvc.wso2greg.model.AddEndpointRequest;
import com.anthem.microsvc.wso2greg.model.AddProxyRequest;
import com.anthem.microsvc.wso2greg.model.Asset;
import com.anthem.microsvc.wso2greg.model.Failures;
import com.anthem.microsvc.wso2greg.service.impl.GovRegService;

@RestController
@RequestMapping("/assets")
public class GovernanceRegistryController {
	@Autowired
	private ExceptionObjFactory expObjFactory;
	
	@Autowired
	private GovRegService gRegSvc;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST, produces= {"application/json"})
	public ResponseEntity<AddAssetResponse> addAsset(@RequestBody AddAssetRequest payload, @RequestHeader Map<String, String> headers) throws Exception{
		AddAssetResponse resp = null;
		if(payload != null && (StringUtils.isEmpty(payload.getProject()) || StringUtils.isEmpty(payload.getServicenm()))) {
			throw new ExceptionObjFactory().createNewAppexception("3001", "Bad Request");
		}
		
		if(!CollectionUtils.isEmpty(headers) && headers.containsKey("Authorization")) {
			resp = gRegSvc.handleAddAsset(payload, headers, false);
		    
		}else {
			throw  expObjFactory.createNewAppexception("3001", "Bad Request");
		}
		
		return new ResponseEntity<AddAssetResponse>(resp, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/add/ms", method = RequestMethod.POST, produces= {"application/json"})
	public ResponseEntity<String> addNewService(@RequestBody AddAssetRequest payload, @RequestHeader Map<String, String> headers) throws Exception{
		
		if(payload != null && (StringUtils.isEmpty(payload.getServicenm()) || StringUtils.isEmpty(payload.getContextRoot()))) {
			throw new ExceptionObjFactory().createNewAppexception("3001", "Bad Request");
		}
		gRegSvc.addNewService(payload);
		return new ResponseEntity<String>("success", HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/add/proxy", method = RequestMethod.POST, produces= {"application/json"})
	public ResponseEntity<String> addNewProxy(@RequestBody AddProxyRequest req, @RequestHeader Map<String, String> headers) throws Exception{
		
		if(StringUtils.isEmpty(req.getProxyName()) || StringUtils.isEmpty(req.getBasePath())) {
			throw new ExceptionObjFactory().createNewAppexception("3001", "Bad Request");
		}
		gRegSvc.addNewProxy(req);
		
		return new ResponseEntity<String>("success", HttpStatus.CREATED);
	}
	@RequestMapping(value = "/cleanup", method = RequestMethod.DELETE, produces= {"application/json"})
	public ResponseEntity<String> cleanUp(@RequestHeader Map<String, String> headers) throws Exception{
		
		gRegSvc.tearDown();
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/proxies/load", method = RequestMethod.POST, produces= {"application/json"} )
	public ResponseEntity<String> loadStaticProxiesData() throws Exception {
		
		gRegSvc.loadStaticProxiesData();
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
		
	}
	@RequestMapping(value = "/consumers/load", method = RequestMethod.POST, produces= {"application/json"} )
	public ResponseEntity<String> loadStaticConsumersData() throws Exception {
		
		gRegSvc.loadStaticConsumersData();
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
		
	}
	
	@RequestMapping(value = "/add/all", method = RequestMethod.POST, produces= {"application/json"} )
	public ResponseEntity<String> loadAllAssets(@RequestBody AddAllAssetsRequest req, @RequestHeader Map<String, String> headers) throws Exception{
		
		gRegSvc.loadAllAssets(req.getProject(), req.getStart(), req.getLimit(), req.getEnv(), headers);
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	
	}
	
	@RequestMapping(value = "/associations", method = RequestMethod.GET, produces= {"application/json"} )
	public ResponseEntity<List<Asset>> getAllAssociatoins(@RequestParam String resource) throws Exception{
		List<Asset> resp = new ArrayList<Asset>();
		
		if(StringUtils.hasText(resource)) {
			resp = gRegSvc.getAllAssets(resource);
		}
		
		return new ResponseEntity<List<Asset>>(resp, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/failures", method = RequestMethod.GET, produces= {"application/json"} )
	public ResponseEntity<Failures> getAllFailedResources(@RequestParam String project, @RequestParam String start, @RequestParam String limit, @RequestHeader Map<String, String> headers) throws Exception{
		Failures resp = new Failures();
		
		if(StringUtils.hasText(project)) {
			resp = gRegSvc.getAllFailures(project, start, limit, headers);
		}
		
		return new ResponseEntity<Failures>(resp, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/add/failures/all", method = RequestMethod.POST, produces= {"application/json"} )
	public ResponseEntity<String> loadAllFailures(@RequestBody AddAssetRequest req, @RequestHeader Map<String, String> headers) throws Exception{
		
		gRegSvc.loadAllFailures(req, headers);
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	
	}
	
	@PostMapping(value = "/upload", produces = {"application/json"})
	public ResponseEntity<String> insertFileData(@RequestParam("file") MultipartFile file, @RequestParam("type") String type) throws IllegalStateException, IOException{
			
		gRegSvc.insertFileData(file, type);
		
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/associations/consumer", method = RequestMethod.POST, produces= {"application/json"} )
	public ResponseEntity<String> addConsumerAssociations(@RequestBody AddConsumerAssociationRequest req, @RequestHeader Map<String, String> headers) throws Exception{
		
		
		if(CollectionUtils.isEmpty(req.getProxies()) || CollectionUtils.isEmpty(req.getSenderApp())) {
			throw new ExceptionObjFactory().createNewAppexception("3001", "Bad Request");
		}
		
		gRegSvc.addProxyConsumerAssociations(req);
		
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	
	}
	
	@RequestMapping(value = "/add/proxy/resource", method = RequestMethod.POST, produces= {"application/json"} )
	public ResponseEntity<String> addNewProxyResource(@RequestBody AddEndpointRequest req, @RequestHeader Map<String, String> headers) throws Exception{
		if(StringUtils.isEmpty(req.getProxyName()) || CollectionUtils.isEmpty(req.getResourceList())) {
			throw new ExceptionObjFactory().createNewAppexception("3001", "Bad Request");
		}
		gRegSvc.addProxyResource(req, true);
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	
	}
	
	@RequestMapping(value = "/add/proxy/resource", method = RequestMethod.PUT, produces= {"application/json"} )
	public ResponseEntity<String> updateProxyResource(@RequestBody AddEndpointRequest req, @RequestHeader Map<String, String> headers) throws Exception{
		if(StringUtils.isEmpty(req.getProxyName()) || CollectionUtils.isEmpty(req.getResourceList())) {
			throw new ExceptionObjFactory().createNewAppexception("3001", "Bad Request");
		}
		gRegSvc.addProxyResource(req, false);
		return new ResponseEntity<String>("Success", HttpStatus.CREATED);
	
	}
	
	@GetMapping(value = "/search", produces = {"application/json"})
	public ResponseEntity<Asset> getAssociations(@RequestParam(value = "uri") String uri, @RequestParam(value = "method") String verb, @RequestHeader Map<String, String> headers) throws Exception{
		
		Asset resp = gRegSvc.getEndpointAssociations(uri, verb);
		
		return new ResponseEntity<Asset>(resp, HttpStatus.OK);
	}
}
