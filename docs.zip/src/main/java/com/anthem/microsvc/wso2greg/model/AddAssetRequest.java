package com.anthem.microsvc.wso2greg.model;

public class AddAssetRequest {

	private String project;
	private String servicenm;
	private String profile;
	private String contextRoot;
	
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getServicenm() {
		return servicenm;
	}
	public void setServicenm(String servicenm) {
		this.servicenm = servicenm;
	}
	public String getContextRoot() {
		return contextRoot;
	}
	public void setContextRoot(String contextRoot) {
		this.contextRoot = contextRoot;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contextRoot == null) ? 0 : contextRoot.hashCode());
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		result = prime * result + ((project == null) ? 0 : project.hashCode());
		result = prime * result + ((servicenm == null) ? 0 : servicenm.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AddAssetRequest other = (AddAssetRequest) obj;
		if (contextRoot == null) {
			if (other.contextRoot != null)
				return false;
		} else if (!contextRoot.equals(other.contextRoot))
			return false;
		if (profile == null) {
			if (other.profile != null)
				return false;
		} else if (!profile.equals(other.profile))
			return false;
		if (project == null) {
			if (other.project != null)
				return false;
		} else if (!project.equals(other.project))
			return false;
		if (servicenm == null) {
			if (other.servicenm != null)
				return false;
		} else if (!servicenm.equals(other.servicenm))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AddAssetRequest [project=" + project + ", servicenm=" + servicenm + ", profile=" + profile
				+ ", contextRoot=" + contextRoot + "]";
	}
	
	
}
