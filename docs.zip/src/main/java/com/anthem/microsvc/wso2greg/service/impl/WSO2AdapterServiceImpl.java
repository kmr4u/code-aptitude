package com.anthem.microsvc.wso2greg.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.anthem.microsvc.wso2greg.constants.Constants;
import com.anthem.microsvc.wso2greg.entities.ApiProxy;
import com.anthem.microsvc.wso2greg.entities.Endpoint;
import com.anthem.microsvc.wso2greg.entities.Proxy;
import com.anthem.microsvc.wso2greg.service.HTTPSenderService;
import com.anthem.microsvc.wso2greg.service.WSO2AdapterService;
import com.anthem.microsvc.wso2greg.util.WSO2Utility;

@Service
public class WSO2AdapterServiceImpl implements WSO2AdapterService{
	private static final Logger logger = LoggerFactory.getLogger(WSO2AdapterService.class);
	
	@Autowired
	private HTTPSenderService sender;
	
	@Value("${wso2.uri}")
	private String wso2Uri;
	
	@Override
	public boolean addService(String serviceName, String contextRoot) throws Exception {
		logger.info("Method Enter: addService("+serviceName+":"+contextRoot+")");
		boolean isSuccess = false;
		if(StringUtils.hasText(contextRoot)) {
			String reqBody = WSO2Utility.createServiceRequestBody(serviceName, contextRoot);
			String resp = sender.sendPayLoad(getWso2Uri()+Constants.ADD_RESOURCE_REST, HttpMethod.POST, reqBody, null);
			if(StringUtils.hasText(resp)) {
				isSuccess = true;
			}
		}else {
			logger.info("Method Exit: addService(): "+isSuccess);
			return isSuccess;
		}
		logger.info("Method Exit: addService(): "+isSuccess);
		return isSuccess;
	}

	@Override
	public void addServiceToDomainAssociation(String serviceName, String domain) throws Exception {
		logger.info("Method Enter: addServiceToDomainAssociation("+serviceName+":"+domain+")");
		domain = Constants.DOMAIN.get(domain);
		String reqBody = WSO2Utility.createAssociationPathServiceToDomainRequestBody(domain);
		String associationPath = WSO2Utility.createAssociationPathService(serviceName);
		sender.sendPayLoad(getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + associationPath, HttpMethod.POST, reqBody, null);
		logger.info("Method Exit: addServiceToDomainAssociation(): ");
	}

	@Override
	public void addServiceToSDSAssociation(String serviceName, String dbName, String address, boolean isSDS) throws Exception {
		logger.info("Method Enter: addServiceToDomainAssociation("+serviceName+":"+dbName+")");
		String resourceUri = getWso2Uri() + (isSDS ? Constants.ADD_RESOURCE_SDS : Constants.ADD_RESOURCE_MICROSDS);
		String payload = WSO2Utility.createSDSMicroSDSRequestBody(dbName, address, isSDS);
		try {
			sender.sendPayLoad(resourceUri, HttpMethod.POST, payload, null);
		}catch(Exception e) {
			logger.error("Error while creating db resource: "+e.getCause());
		}
		
		
		String uri = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathService(serviceName);
		String reqBody = WSO2Utility.createAssociationPathServiceToSDSRequestBody(dbName, isSDS);
		sender.sendPayLoad(uri, HttpMethod.POST, reqBody, null);
		
		String url = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathSDSMicroSDS(dbName, isSDS);
		String req = WSO2Utility.createAssociationPathSDSToServiceRequestBody(serviceName);
		sender.sendPayLoad(url, HttpMethod.POST, req, null);
		logger.info("Method Exit: addServiceToSDSAssociation(): ");
	}

	@Override
	public void addApigeeProxyConsumers(String serviceName) throws Exception {

		
	}

	@Override
	public void addServiceToAPIGEEAssociation(String serviceName, Proxy proxy) throws Exception {
		logger.info("Method Enter: addServiceToAPIGEEAssociation("+serviceName+":"+proxy.getProxy()+")");
		/*String uri = Constants.WSO2URI + Constants.ADD_RESOURCE_APIGEE;
		String reqBody = WSO2Utility.createAPIGEERequestBody(proxy.getProxy(), proxy.getBasePath());
		sender.sendPayLoad(uri, HttpMethod.POST, reqBody, null);*/
		
		/*WSO2Utility.getHttpResponse(WSO2URI + Constants.ADD_RESOURCE_APIGEE, Constants.WSO2_CREDS, "POST",
				WSO2Utility.createAPIGEERequestBody(proxy.getProxyName(), proxy.getResourceEndpoint()), null);*/
		String uri = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathService(serviceName);
		String reqBody = WSO2Utility.createAssociationPathAPIGEEProxyRequestBody(proxy.getProxy());
		sender.sendPayLoad(uri, HttpMethod.POST, reqBody, null);
		
		logger.info("Method Exit: addServiceToAPIGEEAssociation(): ");
		
	}

	@Override
	public void addEndpointsToAPIGEEAssociation(String proxyName, String api, String endpoint)
			throws Exception {
		
		try {
			String endPointUri = getWso2Uri() + Constants.ADD_RESOURCE_ENDPOINT;
			String payLoad = WSO2Utility.createEndpointRequestBody(api, endpoint);
			try {
				sender.sendPayLoad(endPointUri, HttpMethod.POST, payLoad, null);
			}catch(Exception e) {
				logger.error("Error while creating EndPoint: Endpoint already exists? ");
			}
						
			String proxyAssociatoinUri = getWso2Uri() + Constants.ADD_ENDPOINTS_APIPROXIES_ASSOCIATION + proxyName;
			//String associateReq = WSO2Utility.createAssociationEndpointsAPIGEEProxyRequestBody(proxy.getApi(), proxy.getBasePath());
			
			sender.sendPayLoad(proxyAssociatoinUri, HttpMethod.POST, payLoad, null);
		}catch(Exception e) {
			logger.error("Error while Endpoint association workflow: "+proxyName+": "+endpoint);
		}
		
	}

	@Override
	public void addSouthboundServiceToEndpointAssociation(String serviceName, String basePath, List<Endpoint> eps) throws Exception {
		
		for(Endpoint ep: eps) {
			//String url = Constants.WSO2URI + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathEndpoint(proxy.getApi(), proxy.getBasePath()+proxy.getResourcePath());
			String target = WSO2Utility.createAssociationPathEndpoint(ep.getApi(), basePath+ep.getResource_path());
			
			//String req = WSO2Utility.createEndpointToServiceAssociationBody(serviceName, true);
			
			//sender.sendPayLoad(url, HttpMethod.POST, req, null);
			
			addSouthboundServiceToEndpointAssociation(serviceName, target.substring(target.indexOf("=")+1));
		}
		
		
		logger.info("Method Exit: addSouthboundServiceToEndpointAssociation(): ");
	}

	@Override
	public void addSouthiboundServiceToAPIGEEAssociation(String serviceName, Proxy proxy) throws Exception {
		logger.info("Method Enter: addSouthiboundServiceToAPIGEEAssociation("+serviceName+":"+proxy.getProxy()+")");
		String uri = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathService(serviceName);
		String reqBody = WSO2Utility.createSouthiboundAssociationPathAPIGEEProxyRequestBody(proxy.getProxy());
		sender.sendPayLoad(uri, HttpMethod.POST, reqBody, null);
		
		logger.info("Method Exit: addSouthiboundServiceToAPIGEEAssociation(): ");
	}

	@Override
	public void addServiceToEndPointAssociation(String serviceName, String basePath, List<Endpoint> endpoints) throws Exception {
		logger.info("Method Enter: addServiceToEndPointAssociation()");
			for(Endpoint ep: endpoints) {
				try {
					logger.info("addServiceToEndPointAssociation("+serviceName+":"+basePath+ep.getResource_path()+")");
					//String endPointUri = Constants.WSO2URI + Constants.ADD_RESOURCE_ENDPOINT;
					//String payLoad = WSO2Utility.createEndpointRequestBody(proxy.getApi(), proxy.getBasePath()+proxy.getResourcePath());
					/*try {
						sender.sendPayLoad(endPointUri, HttpMethod.POST, payLoad, null);
					}catch(Exception e) {
						logger.error("Error while creating EndPoint: Endpoint already exists? ");
					}*/
					
					//String restServiceUri = Constants.WSO2URI + Constants.ADD_ENDPOINTS_RESTSERVICE_ASSOCIATION + serviceName;
					//String reqBody = WSO2Utility.createServiceToEndpointAssociationBody(proxy.getApi(), proxy.getBasePath());
					
					//sender.sendPayLoad(restServiceUri, HttpMethod.POST, payLoad, null);
					
					String url = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathEndpoint(ep.getApi(), basePath+ep.getResource_path());
					String req = WSO2Utility.createEndpointToServiceAssociationBody(serviceName, false);
					
					sender.sendPayLoad(url, HttpMethod.POST, req, null);
					
					/*String proxyAssociatoinUri = Constants.WSO2URI + Constants.ADD_ENDPOINTS_APIPROXIES_ASSOCIATION + proxy.getProxy();
					//String associateReq = WSO2Utility.createAssociationEndpointsAPIGEEProxyRequestBody(proxy.getApi(), proxy.getBasePath());
					
					sender.sendPayLoad(proxyAssociatoinUri, HttpMethod.POST, payLoad, null);*/
				}catch(Exception e) {
					logger.error("Error while Endpoint association workflow: "+serviceName+": "+basePath+ep.getResource_path());
				}
				
			}
		
		
		logger.info("Method Exit: addServiceToEndPointAssociation(): ");
	}

	@Override
	public void addResourceProxy(String name, String basePath) throws Exception {
		logger.info("Method Enter: addResourceProxy("+name+":"+basePath+")");
		String url = getWso2Uri() + Constants.ADD_RESOURCE_APIGEE;
		String payLoad = WSO2Utility.createAPIGEERequestBody(name, basePath);
		
		sender.sendPayLoad(url, HttpMethod.POST, payLoad, null);
		
		logger.info("Method Exit: addResourceProxy(): ");
	}

	@Override
	public void addProxyToConsumerAssociation(String proxy, Iterable<String> consumers) throws Exception {
		
		String url = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathAPIProxy(proxy);
		String reqBody = WSO2Utility.createAssociationPathConsumerRequestBody(consumers);
		try {
			sender.sendPayLoad(url, HttpMethod.POST, reqBody, null);
		}catch(Exception e) {
			logger.error("Error while adding consumer associations for proxy: "+proxy+". Cause: "+e.getCause());
		}
		
	}
	
	@Override
	public void addResourceConsumer(String consumer) throws Exception{
		
		String url = getWso2Uri() + Constants.ADD_RESOURCE_CONSUMERS;
		String reqBody = WSO2Utility.createConsumersRequestBody(consumer);
		
		try {
			sender.sendPayLoad(url, HttpMethod.POST, reqBody, null);
		}catch(Exception e) {
			logger.error("Error while adding consumer: "+consumer+". Cause: "+e.getCause());
		}
		
	}

	@Override
	public String getAllAssets(String resourceName) throws Exception {
		
		String uri = getWso2Uri() + (resourceName.equalsIgnoreCase("microsds") ? Constants.ADD_RESOURCE_MICROSDS : Constants.ADD_RESOURCE_SDS);
		
		String resp = sender.invokeGET(uri, null, false, false);
		
		return resp;
	}

	@Override
	public String getAllAssociations(String path) throws Exception {
		// TODO Auto-generated method stub
		String uri = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + "?path="+path;
		
		String resp = sender.invokeGET(uri, null, false, false);
		
		return resp;
	}

	@Override
	public String getAllSDSAssociations(String type, String asset) throws Exception {
		// TODO Auto-generated method stub
		
		return null;
	}
	
	@Override
	public String getAssetByName(String name, String type) throws Exception{
		
		String uri = getWso2Uri() + (type.equals("restservices") ? Constants.ADD_RESOURCE_REST : Constants.ADD_RESOURCE_APIGEE) + "?name="+name;
		
		String resp = sender.invokeGET(uri, null, false, false);
		
		return resp;
	}

	@Override
	public void addSouthboundServiceToEndpointAssociation(String serviceName, String endpoint) throws Exception {
		logger.info("Method Enter: addSouthboundServiceToEndpointAssociation("+serviceName+": "+endpoint+")");
		
		String url = getWso2Uri() + Constants.ADD_RESOURCE_ASSOCIATION + WSO2Utility.createAssociationPathService(serviceName);
		String req = WSO2Utility.createSouthBoundServiceToEndpointAssociationBody(endpoint);
		
		sender.sendPayLoad(url, HttpMethod.POST, req, null);
		
		logger.info("Method Enter: addSouthboundServiceToEndpointAssociation()");
	}
	
	private String getWso2Uri() {
		return wso2Uri;
	}
}
