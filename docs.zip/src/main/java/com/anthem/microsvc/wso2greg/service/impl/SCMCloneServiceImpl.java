package com.anthem.microsvc.wso2greg.service.impl;

import org.eclipse.jgit.api.Git;
import org.springframework.stereotype.Component;

import com.anthem.microsvc.wso2greg.service.SCMCloneService;
import com.anthem.microsvc.wso2greg.util.WSO2Utility;

@Component
public class SCMCloneServiceImpl implements SCMCloneService {

	@Override
	public void cloneRepo(String project, String service, String[] cred) throws Exception {
		
		String serviceFolder = WSO2Utility.getFolderPath() + service;
		Git git = null;
		try {
			git = WSO2Utility.cloneRepository(WSO2Utility.getScmCloneUrl(cred[0], project, service), serviceFolder, cred[0], cred[1]);
		}catch(Exception e) {
			WSO2Utility.deleteDir(service);
			throw e;
		}
		finally {
			git.close();
		}
	}

	
}
