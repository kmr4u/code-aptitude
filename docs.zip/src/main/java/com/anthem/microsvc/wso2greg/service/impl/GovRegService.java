package com.anthem.microsvc.wso2greg.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import javax.net.ssl.SSLContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.anthem.emep.common.exception.helper.ExceptionObjFactory;
import com.anthem.microsvc.wso2greg.ServiceConfigUrlProps;
import com.anthem.microsvc.wso2greg.constants.Constants;
import com.anthem.microsvc.wso2greg.entities.Consumer;
import com.anthem.microsvc.wso2greg.entities.Endpoint;
import com.anthem.microsvc.wso2greg.entities.MsInventory;
import com.anthem.microsvc.wso2greg.entities.Proxy;
import com.anthem.microsvc.wso2greg.model.AddAssetRequest;
import com.anthem.microsvc.wso2greg.model.AddAssetResponse;
import com.anthem.microsvc.wso2greg.model.AddConsumerAssociationRequest;
import com.anthem.microsvc.wso2greg.model.AddEndpointRequest;
import com.anthem.microsvc.wso2greg.model.AddProxyRequest;
import com.anthem.microsvc.wso2greg.model.Asset;
import com.anthem.microsvc.wso2greg.model.Config;
import com.anthem.microsvc.wso2greg.model.Failures;
import com.anthem.microsvc.wso2greg.model.Resource;
import com.anthem.microsvc.wso2greg.service.CodeBaseParser;
import com.anthem.microsvc.wso2greg.service.ConfigSourceReader;
import com.anthem.microsvc.wso2greg.service.GovernanceDBService;
import com.anthem.microsvc.wso2greg.service.HTTPSenderService;
import com.anthem.microsvc.wso2greg.service.SCMCloneService;
import com.anthem.microsvc.wso2greg.service.WSO2AdapterService;
import com.anthem.microsvc.wso2greg.util.WSO2Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

@Component
public class GovRegService {
	private static final Logger logger = LoggerFactory.getLogger(GovRegService.class);
	@Autowired
	private SCMCloneService scmCloneSvc;
	@Autowired
	private CodeBaseParser parser;
	@Autowired
	private ExceptionObjFactory expObjFactory;
	@Autowired
	private ConfigSourceReader configSrc;
	@Autowired
	private WSO2AdapterService wso2Svc;
	@Autowired
	private GovernanceDBService dbSvc;
	@Autowired
	private HTTPSenderService sender;
	@Autowired
	private ObjectMapper mapper;
	@Autowired
	private ServiceConfigUrlProps urlConfig;
	
	@Value("${wso2.uri}")
	private String wso2Uri;
	@Value("{wso2.creds}")
	private String creds;

	public AddAssetResponse handleAddAsset(AddAssetRequest req, Map<String, String> headers, boolean isStatic) throws Exception {
		AddAssetResponse resp = new AddAssetResponse();
		String authStr = headers.get("Authorization");
		String base64Credentials = authStr.substring("Basic".length()).trim();
	    byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
	    String credentials = new String(credDecoded, StandardCharsets.UTF_8);
	    // credentials = username:password
	    final String[] creds = credentials.split(":", 2);
	    try {
	    	scmCloneSvc.cloneRepo(req.getProject(), req.getServicenm(), creds);
	    	
	    	String configUrl = !isStatic ? parser.parseBootstrap(req.getServicenm(), req.getProfile()) : urlConfig.getConfigUrlMap(req.getProject()).get(req.getServicenm());
	    	
	    	boolean isNode = StringUtils.hasText(configUrl) && configUrl.contains(".json");
	    	Config config = new Config();
	    	if(StringUtils.hasText(configUrl)) {
	    		config = configSrc.readConfigProps(configUrl, headers, isNode);
	    	}else {
	    		config = parser.parseBootstrapForMongo(config, req.getServicenm(), req.getProfile());
	    	}
	    	parser.findInFiles(config, req.getServicenm(), true, true, isNode);
	    	
	    	String contextRoot = dbSvc.getContextRoot(req.getServicenm());
	    	if(StringUtils.hasText(contextRoot)) {
	    		boolean addService = wso2Svc.addService(req.getServicenm(), contextRoot);
		    	
		    	wso2Svc.addServiceToDomainAssociation(req.getServicenm(), req.getProject());
		    	if(config.getProperties().values().stream().anyMatch(v -> v.toString().contains(":oracle:"))) {
		    		String property =config.getProperties().values().stream().filter(v -> v.toString().contains(":oracle:")).findFirst().get().toString();
		    		String dbName = property.substring(property.lastIndexOf("/")+1, property.length());
		    		String address = property.substring(property.lastIndexOf("@")+1, property.lastIndexOf("/"));
		    		wso2Svc.addServiceToSDSAssociation(req.getServicenm(), dbName, address, true);
		    	}
		    	if(config.getProperties().values().stream().anyMatch(v -> v.toString().contains("mongodb:"))) {
		    		String property = config.getProperties().values().stream().filter(v -> v.toString().contains("mongodb:")).findFirst().get().toString();
		    		String dbName = property.substring(property.lastIndexOf("/")+1, property.indexOf("?") != -1 ? property.indexOf("?"):property.length());
		    		String address = property.substring(property.lastIndexOf("@")+1, property.lastIndexOf("/"));
		    		wso2Svc.addServiceToSDSAssociation(req.getServicenm(), dbName, address, false);
		    	}
		    	List<Proxy> proxies = getApiProxies(contextRoot);
		    	if(!CollectionUtils.isEmpty(proxies)) {
		    		for(Proxy proxy: proxies) {
			    		wso2Svc.addServiceToAPIGEEAssociation(req.getServicenm(), proxy);
			    		wso2Svc.addServiceToEndPointAssociation(req.getServicenm(), proxy.getProxy(), proxy.getEndPoints());
			    	}
		    	}
		    	
		    	
		    	List<String> resources = getOutBoundApiUrls(config);
		    	Map<String, List<Proxy>> outBoundProxiesMap = getApiProxies(resources);
		    	List<Proxy> outBoundEndpoints = outBoundProxiesMap.get("endpoint");
		    	if(!CollectionUtils.isEmpty(outBoundEndpoints)) {
		    		for(Proxy proxy: outBoundEndpoints) {
			    		wso2Svc.addSouthiboundServiceToAPIGEEAssociation(req.getServicenm(), proxy);
			    		wso2Svc.addSouthboundServiceToEndpointAssociation(req.getServicenm(), proxy.getProxy(), proxy.getEndPoints());
			    	}
			    	List<Proxy> possibleOBEndpoints = outBoundProxiesMap.get("proxy");
			    	if(!CollectionUtils.isEmpty(possibleOBEndpoints)) {
			    		for(Proxy proxy: possibleOBEndpoints) {
				    		wso2Svc.addSouthiboundServiceToAPIGEEAssociation(req.getServicenm(), proxy);
				    		/*List<String> endpoints = getAllProxyEndpointAssociations(Constants.REST_ASSOCIATION_PROXY+proxy.getProxy());
				    		for(String target: endpoints) {
				    			wso2Svc.addSouthboundServiceToEndpointAssociation(req.getServicenm(), target);
				    		}*/
				    	}
			    	}
		    	}
		    	
		    	resp.setSuccess(addService);
	    	}
	    	
	    }catch(Exception e) {
	    	if(e instanceof InvalidRemoteException || e instanceof TransportException || e instanceof GitAPIException) {
	    		logger.error("Error while cloning the repo: "+e.getCause());
	    		throw expObjFactory.createNewAppexception("3002", "Error while cloning the repo");
	    	}else if(e instanceof FileNotFoundException){
	    		logger.error("Bootstrap.yml FileNotFound");
	    		throw expObjFactory.createNewAppexception("3002", "Bootstrap.yml FileNotFound");
	    	}else {
	    		logger.error("Error while executing the workflow for the service: "+req.getServicenm()+"\n "+e.getCause());
	    		throw e;
	    	}
	    	
	    }
	    finally {
	    	WSO2Utility.deleteDir(req.getServicenm());
	    }
		return resp;
	}
	
	private List<Proxy> getApiProxies(String contextRoot){
		return dbSvc.getAPIGEEProxy(contextRoot);
	}
	private Map<String, List<Proxy>> getApiProxies(List<String> resourcePaths){
		
		return dbSvc.getAPIGEEProxyByResourceName(resourcePaths);
	}
	
	private List<String> getOutBoundApiUrls(Config config){
		
		return config.getProperties().values().stream().map(v -> {
			if(v.toString().contains("api.anthem.com")) {
				return v.toString().split("com")[1];
			}
			return "";
		}).collect(Collectors.toList());
		
	}
	
	public void loadStaticProxiesData() throws Exception {
		
		List<Object[]> res = dbSvc.getAllProxies();
		
		Map<String, String> proxies = new HashMap<>();
		for(Object[] row: res) {
			if(null != row[0] && null != row[1]) {
				proxies.put((String)row[0], (String)row[1]);
			}
		}
		
		for(Map.Entry<String, String> entry: proxies.entrySet()) {
			wso2Svc.addResourceProxy(entry.getKey(), entry.getValue());
		}
		List<Object[]> endpoints  = dbSvc.getAPIGEEProxyEndpoint();
		for(Object[] entry: endpoints) {
			wso2Svc.addEndpointsToAPIGEEAssociation((String)entry[0], (String)entry[1], (String)entry[2]+(String)entry[3]);
		}
	}
	
	public void loadAllAssets(String domain, String start, String limit, String env, Map<String, String> headers) throws Exception{
		
		try {
			String resp = sender.invokeGET("https://bitbucket.anthem.com/rest/api/latest/projects/"+domain+"/repos?start="+start+"&limit="+limit, headers, false, false);
			ObjectMapper mapper = new ObjectMapper();
			
			JsonNode node = mapper.readValue(resp, JsonNode.class);
			ExecutorService  executor1 = Executors.newSingleThreadExecutor();
			ExecutorService executor2 = Executors.newSingleThreadExecutor();
			ExecutorService executor3 = Executors.newSingleThreadExecutor();
			//List<Callable<String>> tasks = new ArrayList<Callable<String>>();
			List<CompletableFuture<String>> futures = new ArrayList<>();
			if(null != node && null != node.get("values")) {
				ArrayNode values = (ArrayNode) node.get("values");
				int i=0;
				for(JsonNode repo: values) {
					/*String service = repo.get("name").asText();
					String reqBody = WSO2Utility.createAddResourceBody(domain, service, env);
					String host = WSO2Utility.generateRandomHost(i);*/
					if(i == 0) {
						futures.add(invokeRESTAsync(headers, executor1, repo, domain, env, "http://localhost:8081"));
					}else if(i == 1) {
						futures.add(invokeRESTAsync(headers, executor2, repo, domain, env, "http://localhost:8082"));
					}else {
						futures.add(invokeRESTAsync(headers, executor3, repo, domain, env, "http://localhost:8083"));
					}
					i++;
					if(i>2) i=0;
					/*Callable<String> c = new Callable<String>() {
		                @Override
		                public String call() throws Exception {
		                	try {
		                		return sender.sendPayLoad(host + Constants.LOCAL_ADD_ASSET, HttpMethod.POST, reqBody, headers);
		                	}catch(Exception e) {
		                		logger.error(Thread.currentThread()+" - Couldn't create resource: "+service);
		                		logger.error(Thread.currentThread()+" - "+e.getCause());
		                	}
							return null;
		                }
		            };
		            tasks.add(c);*/
					/*executor.submit(() -> {
						try {
							String host = WSO2Utility.generateRandomHost(3);
							System.out.println("host: "+host+" - "+Thread.currentThread());
							sender.sendPayLoad(host + Constants.LOCAL_ADD_ASSET, HttpMethod.POST, reqBody, headers);
						} catch (Exception e) {
							logger.error("Couldn't create resource: " + service);
						}

					});*/
				}
				
				try {
		            long begin = System.currentTimeMillis();
		            for(CompletableFuture<String> future: futures) {
		            	future.get();
		            }
		            long elapsed = System.currentTimeMillis() - begin;
		            logger.info("Elapsed time: "+elapsed);
		        }catch(Exception e) {
		        	logger.error("Exception while reading the response from thread: "+e.getCause());
		        } finally {
		            executor1.shutdown();
		            executor2.shutdown();
		            executor3.shutdown();
		        }
			}
		}catch(Exception e) {
			logger.error("Error while adding all resources: "+e.getCause());
			throw e;
		}
		
	}

	private CompletableFuture<String> invokeRESTAsync(Map<String, String> headers, ExecutorService executor, JsonNode repo, String domain, String env, String host) {
		return CompletableFuture.supplyAsync(() -> {
			String service = repo.get("name").asText();
			String reqBody = createAddResourceBody(domain, service, env);
			try {
				return sendPayLoad(host + Constants.LOCAL_ADD_ASSET, HttpMethod.POST, reqBody, headers);
			} catch (Exception e) {
				try {
					logger.error("Failed to add service: "+service+" - "+e.getCause());
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
			return null;
		}, executor);
	}
	
	public void loadStaticConsumersData() throws Exception {
		List<Proxy> res = dbSvc.getAllConsumers();
		Map<String, List<String>> associations = new HashMap<>();
		Set<String> consumers = new HashSet<>();
		if(!CollectionUtils.isEmpty(res)) {
			for(Proxy row : res) {
				List<String> usedBy = new ArrayList<>();
				if(CollectionUtils.isEmpty(row.getConsumers())) {
					for(Consumer consumer: row.getConsumers()) {
						consumers.add(consumer.getConsumer_name());
						usedBy.add(consumer.getConsumer_name());
					}
					associations.put(row.getProxy(), usedBy);	
				}
				
			}
		}
		
		for(String consumer: consumers) {
			wso2Svc.addResourceConsumer(consumer);
		}
		
		for(Map.Entry<String, List<String>> association: associations.entrySet()) {
			wso2Svc.addProxyToConsumerAssociation(association.getKey(), association.getValue());
			
		}
	}
	
	public List<Asset> getAllAssets(String resourceName) throws Exception {
		
		String resp = wso2Svc.getAllAssets(resourceName);
		
		List<Asset> associations = new ArrayList<>();
		
		if(StringUtils.hasText(resp)) {
			JsonNode json = mapper.readTree(resp);
			if(null != json.get("assets") && json.get("assets") instanceof ArrayNode) {
				ArrayNode assets = (ArrayNode)json.get("assets");
				if(null != assets && assets.size() > 0) {
					for(JsonNode node: assets) {
						Asset asset = new Asset();
						String name = node.get("name").asText();
						String type = node.get("type").asText();
						asset.setName(name);
						asset.setType(type);
						asset.setAddress(node.get("address").asText());
						Map<String, String> usedBy = getAllSDSAssociations(type, name);
						for(Map.Entry<String, String> entry: usedBy.entrySet()) {
							Asset service = new Asset();
							service.setName(entry.getKey());
							service.setType("restservice");
							service.setAddress(getAddress(entry.getKey(), entry.getValue()));
							Map<String, String> proxies = getAllServiceAssociations(entry.getValue());
							for(Map.Entry<String, String> proxy: proxies.entrySet()) {
								Asset api = new Asset();
								api.setName(proxy.getKey());
								api.setType("apiproxy");
								api.setAddress(getAddress(proxy.getKey(), proxy.getValue()));
								Map<String, String> consumers = getAllProxyConsumerAssociations(proxy.getValue());
								for(Map.Entry<String, String> consumerEntry: consumers.entrySet()) {
									Asset consumer = new Asset();
									consumer.setName(consumerEntry.getKey());
									consumer.setType("consumer");
									api.getUsedBy().add(consumer);
								}
								service.getUsedBy().add(api);
							}
							asset.getUsedBy().add(service);
						}
						associations.add(asset);
					}
				}
			}
		}
		
		return associations;
	}
	
	public Map<String, String> getAllSDSAssociations(String type, String asset) throws Exception{
		
		String path = ("microsds".equalsIgnoreCase(type) ? Constants.MICROSDS_PATH : Constants.SDS_PATH) + asset;
		
		String resp = wso2Svc.getAllAssociations(path);
		
		Map<String, String> associations = new HashMap<>();
		if(StringUtils.hasText(resp)) {
			ArrayNode json = (ArrayNode)mapper.readTree(resp);
			
			for(JsonNode node: json) {
				if(node.get("source").asText().contains(asset)) {
					String target = node.get("target").asText();
					associations.put(target.substring(target.lastIndexOf("/")+1), target);
				}
			}
		}
		
		return associations;
	}
	
	private String getAddress(String name, String target) throws Exception {
		logger.info("Method Enter: getAddress("+name+")");
		
		String address = "";
		String resp = "";
		boolean isSds=false, isProxy=false, isMs=false;
		if (target.contains("restservices")) {
			isMs=true;
			resp = wso2Svc.getAssetByName(name, "restservices");	
		} else if (target.contains("apiproxy")) {
			isProxy = true;
			resp = wso2Svc.getAssetByName(name, "apiproxys");
		}
		else if(target.contains("ehubsds")) {
			isSds = true;
			resp = wso2Svc.getAssetByName(name, "ehubsds");
		}
		else if(target.contains("microsds")) {
			isSds = true;
			resp = wso2Svc.getAssetByName(name, "microsds");
		}
		
		
		if (StringUtils.hasText(resp)) {
			JsonNode json = mapper.readTree(resp);
			ArrayNode assets = (ArrayNode) json.get("assets");
			JsonNode asset = assets.get(0);
			
			if(isMs) address = asset.get("context").asText() + ":" + asset.get("id").asText();
			else if(isProxy) address = asset.get("basePath").asText() + ":" + asset.get("id").asText();
			else if(isSds) address = asset.get("address").asText();
		}
		
		logger.info("Method Exit: getAddress()");
		return address;
	}
	
	public Map<String, String> getAllServiceAssociations(String path) throws Exception{
		
		String resp = wso2Svc.getAllAssociations(path); 
		Map<String, String> proxies = new HashMap<>();
		if(StringUtils.hasText(resp)) {
			ArrayNode arr = (ArrayNode)mapper.readTree(resp);
			for(JsonNode node : arr) {
				String source = node.get("source").asText();
				String target = node.get("target").asText();
				if(path.equals(source) && target.contains(Constants.REST_ASSOCIATION_PROXY)) {
					proxies.put(target.substring(target.lastIndexOf("/")+1), target);
				}
			}
		}
		
		return proxies;
	}
	
	public Map<String, String> getAllProxyConsumerAssociations(String path) throws Exception{
		String resp = wso2Svc.getAllAssociations(path); 
		Map<String, String> consumers = new HashMap<>();
		
		if(StringUtils.hasText(resp)) {
			ArrayNode arr = (ArrayNode)mapper.readTree(resp);
			for(JsonNode node : arr) {
				String source = node.get("source").asText();
				String target = node.get("target").asText();
				if(path.equals(source) && target.contains(Constants.REST_ASSOCIATION_CONSUMER)) {
					consumers.put(target.substring(target.lastIndexOf("/")+1), target);
				}
			}
		}
		
		return consumers;
	}
	
	private String sendPayLoad(String uri, HttpMethod method, String reqBody, Map<String, String> headers) throws Exception{
		String resp = null;
		ResponseEntity<String> restResp = null;
		HttpHeaders reqHeaders = new HttpHeaders();
		if(!MapUtils.isEmpty(headers) && headers.containsKey("Authorization")) {
			reqHeaders.add("Authorization", headers.get("Authorization"));
		}else {
			reqHeaders.add("Authorization", creds);
		}
		reqHeaders.setContentType(MediaType.APPLICATION_JSON);
		//reqHeaders.add("apikey", null);
		
		try { 
			TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
	            @Override
	            public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
	                return true;
	            }
	        };
	        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
	        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, new NoopHostnameVerifier());
	        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
	        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
	        requestFactory.setHttpClient(httpClient);
	        requestFactory.setConnectTimeout(15000);
	        requestFactory.setReadTimeout(15000);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			
			UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(uri).build();
			HttpEntity<String> requestEntity = new HttpEntity<>(reqBody, reqHeaders);
			
			restResp = restTemplate.exchange(uriComponents.encode().toUri(), method, requestEntity, String.class);
			//httpResp = WSO2Utility.getHttpResponse(uri,  Constants.WSO2_CREDS, method.toString(), reqBody, null);
		}catch(Exception e) {
			throw e;
		}
		
		if(restResp != null && restResp.getStatusCode().is2xxSuccessful()) {
			if(StringUtils.hasText(restResp.getBody()))
				return restResp.getBody().toString();
			else {
				return "Success";
			}
		}
		/*if(httpResp != null && httpResp.getStatusCode().is2xxSuccessful()) {
			return httpResp.getLocation();
		}*/
		return resp;
		
	}
	private String createAddResourceBody(String project, String service, String env) {
		JSONObject request = new JSONObject();
		try {
			request.put("project", project);
			request.put("servicenm", service);
			request.put("profile", env);
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return request.toString();
		
	}
	
	public Failures getAllFailures(String project, String start, String limit, Map<String, String> headers) throws JsonProcessingException, IOException{
		
		Failures failures = new Failures();
		List<String> failed = new ArrayList<>();
		
		String repos = sender.invokeGET("https://bitbucket.anthem.com/rest/api/latest/projects/"+project+"/repos?start="+start+"&limit="+limit, headers, false, false);
		Set<String> active = new HashSet<>();
		Set<String> allServices = new HashSet<>();
		if(StringUtils.hasText(repos)) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode node = mapper.readValue(repos, JsonNode.class);
			if(node != null && node.get("values") != null) {
				ArrayNode arr = (ArrayNode)node.get("values");
				for(JsonNode service: arr) {
					String name = service.get("name").asText();
					allServices.add(name);
					
					/*String uri = Constants.WSO2URI + Constants.ADD_RESOURCE_REST + "?name="+name;
					String resp = sender.invokeGET(uri, null, false);
					if(!StringUtils.hasText(resp)) failures.add(name);*/
				}
				
				active = dbSvc.getAllServicesWithContextRoots(allServices);
				for(String service: active) {
					String uri = getWso2Uri() + Constants.ADD_RESOURCE_REST + "?name="+service;
					String resp = sender.invokeGET(uri, null, false, false);
					if(!StringUtils.hasText(resp)) failed.add(service);
				}
				
				failures.getFailed().addAll(failed);
				allServices.removeAll(active);
				failures.getContextRootMissing().addAll(allServices);
			}
		}
		
		return failures;
		
	}	
	
	public void tearDown() throws Exception {
		deleteAPIConsumers();
		//deleteDomains();
		deleteAPIProxies();
		deleteEhubSDS();
		deleteMicroSDS();
		deleteMSServices();
		deleteEndPoints();
	}

	private void deleteAPIConsumers() throws Exception {

		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_CONSUMERS + "?start=0&count=1000";

			String response = sender.invokeGET(uri, null, false, false);

			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();
				
				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_CONSUMERS + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
			}
		} catch (Exception e) {
			logger.error("Error while cleaning up consumers: "+e.getMessage());
		}
	}

	private void deleteDomains() throws Exception {

		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_DOMAINS;
				
			String response = sender.invokeGET(uri, null, false, false);
	
			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();
				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_DOMAINS + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
			}
		} catch (Exception e) {
			logger.error("Error while cleaning up domains: "+e.getMessage());
		}
	}

	private void deleteAPIProxies() throws Exception {

		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_APIGEE + "?start=0&count=1000";

			String response = sender.invokeGET(uri, null, false, false);

			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();
				
				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_APIGEE + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
			}
		} catch (Exception e) {
			logger.error("Error while cleaning up proxies: "+e.getMessage());
		}
	}

	private void deleteEhubSDS() throws Exception {

		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_SDS;
			
			String response = sender.invokeGET(uri, null, false, false);
			
			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();
				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_SDS + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
			}
		} catch (Exception e) {
			logger.error("Error while cleaning up ehubsds: "+e.getMessage());
		}
	}

	private void deleteMicroSDS() throws Exception {

		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_MICROSDS;
			
			String response = sender.invokeGET(uri, null, false, false);
			
			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();

				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_MICROSDS + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
			}
		} catch (Exception e) {
			logger.error("Error while cleaning up microsds: "+e.getMessage());
		}
	}

	private void deleteMSServices() throws Exception {

		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_REST + "?start=0&count=1000";
			
			String response = sender.invokeGET(uri, null, false, false);

			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();
				
				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_REST + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
				/*WSO2Utility.getHttpResponse(WSO2URI + Constants.ADD_RESOURCE_REST + "/" + guid,
						Constants.WSO2_CREDS, "DELETE", null, null);*/

			}
		} catch (Exception e) {
			logger.error("Error while cleaning up ms: "+e.getMessage());
		}
	}
	
	private void deleteEndPoints() {
		try {
			String uri = getWso2Uri() + Constants.ADD_RESOURCE_ENDPOINT + "?start=0&count=1000";
			
			String response = sender.invokeGET(uri, null, false, false);
		
			JsonNode node = mapper.readTree(response);
			ArrayNode assets = (ArrayNode)node.get("assets");
			
			String guid = "";

			for (int count = 0; count < assets.size(); count++) {
				JsonNode asset = assets.get(count);
				guid = asset.get("id").asText();
				
				String deleteUri = getWso2Uri() + Constants.ADD_RESOURCE_ENDPOINT + "/" + guid;
				sender.invokeGET(deleteUri, null, false, true);
			}
		} catch (Exception e) {
			logger.error("Error while cleaning up endpoint: "+e.getMessage());
		}
	
	}
	
	
	private List<String> getAllProxyEndpointAssociations(String path) throws Exception{
		String resp = wso2Svc.getAllAssociations(path); 
		List<String> endpoints = new ArrayList<>();
		
		if(StringUtils.hasText(resp)) {
			ArrayNode arr = (ArrayNode)mapper.readTree(resp);
			for(JsonNode node : arr) {
				String source = node.get("source").asText();
				String target = node.get("target").asText();
				if(path.equals(source) && target.contains(Constants.REST_ASSOCIATION_ENDPOINT)) {
					endpoints.add(target);
				}
			}
		}
		
		return endpoints;
	}
	
	
	public void loadAllFailures(AddAssetRequest req, Map<String, String> headers) throws Exception {
		
		
		Map<String, String> mbrServices = urlConfig.getConfigUrlMap("SOADMBR");
		for(Map.Entry<String, String> service: mbrServices.entrySet()) {
			AddAssetRequest request = new AddAssetRequest();
			request.setServicenm(service.getKey());
			request.setProject("SOADMBR");
			request.setProfile("uat");
			try {
				handleAddAsset(request, headers, true);
			}catch(Exception e) {
				logger.error("Error while adding service: "+req.getServicenm()+": "+e.getMessage());
			}
			
		}
		
		Map<String, String> utlServices = urlConfig.getConfigUrlMap("SOADUTL");
		for(Map.Entry<String, String> service: utlServices.entrySet()) {
			AddAssetRequest request = new AddAssetRequest();
			request.setServicenm(service.getKey());
			request.setProject("SOADUTL");
			request.setProfile("uat");
			try {
				handleAddAsset(request, headers, true);
			}catch(Exception e) {
				logger.error("Error while adding service: "+req.getServicenm()+": "+e.getMessage());
			}
			
		}
		
		Map<String, String> pdtServices = urlConfig.getConfigUrlMap("SOADPDT");
		for(Map.Entry<String, String> service: pdtServices.entrySet()) {
			AddAssetRequest request = new AddAssetRequest();
			request.setServicenm(service.getKey());
			request.setProject("SOADPDT");
			request.setProfile("uat");
			try {
				handleAddAsset(request, headers, true);
			}catch(Exception e) {
				logger.error("Error while adding service: "+req.getServicenm()+": "+e.getMessage());
			}
			
		}
		Map<String, String> nexGenServices = urlConfig.getConfigUrlMap("NEXGENENG");
		for(Map.Entry<String, String> service: nexGenServices.entrySet()) {
			AddAssetRequest request = new AddAssetRequest();
			request.setServicenm(service.getKey());
			request.setProject("NEXGENENG");
			request.setProfile("uat");
			try {
				handleAddAsset(request, headers, true);
			}catch(Exception e) {
				logger.error("Error while adding service: "+req.getServicenm()+": "+e.getMessage());
			}
			
		}
		Map<String, String> clmServices = urlConfig.getConfigUrlMap("SOADCLM");
		for(Map.Entry<String, String> service: clmServices.entrySet()) {
			AddAssetRequest request = new AddAssetRequest();
			request.setServicenm(service.getKey());
			request.setProject("SOADCLM");
			request.setProfile("uat");
			try {
				handleAddAsset(request, headers, true);
			}catch(Exception e) {
				logger.error("Error while adding service: "+req.getServicenm()+": "+e.getMessage());
			}
			
		}
	}
	
	public void insertFileData(MultipartFile file, String type) throws IllegalStateException, IOException {
		File csvFile = new File(System.getProperty(Constants.USER_DIR)+"\\"+file.getOriginalFilename());
		file.transferTo(csvFile);
		try {
			if("apigee".equals(type)) {
				Set<Proxy> proxies = WSO2Utility.getApiProxies(System.getProperty(Constants.USER_DIR)+"\\"+file.getOriginalFilename());
				dbSvc.saveApiProxies(proxies);
			}else if("ms".equals(type)) {
				List<MsInventory> ms = WSO2Utility.getMsContextRoots(System.getProperty(Constants.USER_DIR)+"\\"+file.getOriginalFilename());
				dbSvc.saveMsInventory(ms);
			}
		}
		
		finally{
			//Files.delete(csvFile);
			Files.delete(Paths.get(System.getProperty(Constants.USER_DIR)+"\\"+file.getOriginalFilename()));
		}
		
	}
	
	private String getWso2Uri() {
		return wso2Uri;
	}
	
	
	public void addNewService(AddAssetRequest req) {
		
		dbSvc.addNewMs(req.getServicenm(), req.getContextRoot());
	}
	
	public void addNewProxy(AddProxyRequest req) {
		
		dbSvc.addNewProxy(req.getProxyName(), req.getBasePath());
	}
	
	
	public void addProxyResource(AddEndpointRequest req, boolean isCreate) {
		List<Endpoint> resources = new ArrayList<>();
		for(Resource resource: req.getResourceList()) {
			Endpoint ep = new Endpoint();
			ep.setApi(resource.getFlowName());
			ep.setHttp_verb(resource.getVerb());
			ep.setTargeServer(resource.getTargetServer());
			ep.setResource_path(resource.getProxyPathSuffix());
			ep.setTargetPath(resource.isTargetCopyPathSuffix() ? resource.getTargetPathSuffix() + resource.getProxyPathSuffix() : resource.getTargetPathSuffix());;
			resources.add(ep);
		}
		
		if(isCreate)
			dbSvc.addNewProxyResources(resources, req.getProxyName());
		else
			dbSvc.updateResource(resources, req.getProxyName());
	}
	
	
	public void addProxyConsumerAssociations(AddConsumerAssociationRequest req) {
		
		dbSvc.addProxyConsumerAssociations(req.getProxies(), req.getSenderApp());
	}
	
	public Asset getEndpointAssociations(String endpoint, String verb) throws Exception {
		
		
		Asset asset = new Asset();
		List<Object[]> res = dbSvc.getEndpointByUri(endpoint, verb);
		
		if(!CollectionUtils.isEmpty(res)) {
			Object[] ep = res.get(0);
			asset.setName((String)ep[0]);
			asset.setAddress((String)ep[1]);
			asset.setType("endpoint");
			
			String path = WSO2Utility.createAssociationPathEndpoint((String)ep[0], (String)ep[1]);
			
			Map<String, List<String>> associations = getAllEndpointAssociations(path);
			for(String key: associations.keySet()) {
				Asset proxy = new Asset();
				proxy.setName(key);
				proxy.setType("apiproxy");
				String[] values = getAddress(key.substring(key.lastIndexOf("/")+1), key).split(":");
				String basePath = values[0];
				String guid = values[1];
				proxy.setAddress(basePath);
				
				asset.getUsedBy().add(proxy);
				
				for(String value: associations.get(key)) {
					Asset ms = new Asset();
					ms.setName(value.substring(value.lastIndexOf("/")+1));
					ms.setType("restservice");
					String[] address = getAddress(value.substring(value.lastIndexOf("/")+1), value).split(":");
					String context = address[0];
					//String guid = address[1];
					ms.setAddress(context);
					
					asset.getInvokes().add(ms);
				}
			}
			
		}
		return asset;
	}
	
	
	private Map<String, List<String>> getAllEndpointAssociations(String path) throws Exception{
		logger.info("Method Enter: getAllEndpointAssociations("+path+")");
		
		String resp = wso2Svc.getAllAssociations(path);
		Map<String, List<String>> map = new HashMap<>();
		
		if(StringUtils.hasText(resp)) {
			String service = null;
			String proxy = null;
			ArrayNode arr = (ArrayNode)mapper.readTree(resp);
			for(JsonNode node : arr) {
				String source = node.get("source").asText();
				String target = node.get("target").asText();
				String type = node.get("type").asText();
				if(path.equals(source) && target.contains(Constants.REST_ASSOCIATION_PATH) && "depends".equals(type)) {
					service = target;
				}if(path.equals(source) && target.contains(Constants.REST_ASSOCIATION_PROXY) && "usedBy".equals(type)) {
					proxy = target;
				}
			}
			if(StringUtils.hasText(service) && StringUtils.hasText(proxy)) {
				List<String> svc = new ArrayList<>();
				if(map.get(proxy) != null) {
					svc = map.get(proxy);
					svc.add(service);
				}else {
					svc.add(service);
				}
				map.put(proxy, svc);
			}
		}
		
		logger.info("Method Exit: getAllEndpointAssociations()");
		return map;
	}
}
