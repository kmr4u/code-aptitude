package com.anthem.microsvc.wso2greg.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.anthem.microsvc.wso2greg.entities.Endpoint;
import com.anthem.microsvc.wso2greg.entities.MsInventory;
import com.anthem.microsvc.wso2greg.entities.Proxy;

public interface GovernanceDBService {

	public String getContextRoot(String servicename);
	
	public List<Proxy> getAPIGEEProxy(String context);
	
	public List<Object[]> getAPIGEEProxyEndpoint();
	
	public Map<String, List<Proxy>> getAPIGEEProxyByResourceName(List<String> resourcePath);
	
	public List<Object[]> getAllProxies();
	
	public List<Proxy> getAllConsumers();
	
	public Set<String> getAllServicesWithContextRoots(Set<String> services);
	
	public void saveApiProxies(Iterable<Proxy> proxies);
	
	public void saveMsInventory(List<MsInventory> ms);
	
	public void addNewMs(String servicenm, String contextRt);
	
	public void addNewProxy(String proxy, String basePath);
	
	public void addNewProxyResources(List<Endpoint> resources, String proxyName);
	
	public void addProxyConsumerAssociations(List<String> proxies, List<String> consumers);
	
	public void updateResource(List<Endpoint> resources, String proxyName);
	
	public List<Object[]> getEndpointByUri(String uri, String verb);
}
