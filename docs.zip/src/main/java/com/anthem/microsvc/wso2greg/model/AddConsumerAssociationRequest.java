package com.anthem.microsvc.wso2greg.model;

import java.util.List;

public class AddConsumerAssociationRequest {

	List<String> senderApp;
	List<String> proxies;
	
	public List<String> getSenderApp() {
		return senderApp;
	}
	public void setSenderApp(List<String> senderApp) {
		this.senderApp = senderApp;
	}
	public List<String> getProxies() {
		return proxies;
	}
	public void setProxies(List<String> proxies) {
		this.proxies = proxies;
	}
}
