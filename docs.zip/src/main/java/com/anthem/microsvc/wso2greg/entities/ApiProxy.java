package com.anthem.microsvc.wso2greg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "api_proxy", schema = "sys")
@IdClass(ApiProxyKey.class)
public class ApiProxy implements Serializable {

	/**
	 * 
	 */
	private String proxy;
	private String api;
	private String httpMethod;
	private String basePath;
	private String resourcePath;
	private String targetHost;
	private String targetPath;
	private String consumers;
	
	@Id
	@Column(name="proxy")
	public String getProxy() {
		return proxy;
	}
	public void setProxy(String proxy) {
		this.proxy = proxy;
	}
	@Id
	@Column(name="api")
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	@Column(name="http_method")
	public String getHttpMethod() {
		return httpMethod;
	}
	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}
	@Column(name="base_path")
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}
	@Column(name="target_host")
	public String getTargetHost() {
		return targetHost;
	}
	public void setTargetHost(String targetHost) {
		this.targetHost = targetHost;
	}
	@Column(name="target_path")
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	@Column(name="consumers")
	public String getConsumers() {
		return consumers;
	}
	public void setConsumers(String consumers) {
		this.consumers = consumers;
	}
	@Column(name="resource_path")
	public String getResourcePath() {
		return resourcePath;
	}
	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((api == null) ? 0 : api.hashCode());
		result = prime * result + ((basePath == null) ? 0 : basePath.hashCode());
		result = prime * result + ((consumers == null) ? 0 : consumers.hashCode());
		result = prime * result + ((httpMethod == null) ? 0 : httpMethod.hashCode());
		result = prime * result + ((proxy == null) ? 0 : proxy.hashCode());
		result = prime * result + ((resourcePath == null) ? 0 : resourcePath.hashCode());
		result = prime * result + ((targetHost == null) ? 0 : targetHost.hashCode());
		result = prime * result + ((targetPath == null) ? 0 : targetPath.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApiProxy other = (ApiProxy) obj;
		if (api == null) {
			if (other.api != null)
				return false;
		} else if (!api.equals(other.api))
			return false;
		if (basePath == null) {
			if (other.basePath != null)
				return false;
		} else if (!basePath.equals(other.basePath))
			return false;
		if (consumers == null) {
			if (other.consumers != null)
				return false;
		} else if (!consumers.equals(other.consumers))
			return false;
		if (httpMethod == null) {
			if (other.httpMethod != null)
				return false;
		} else if (!httpMethod.equals(other.httpMethod))
			return false;
		if (proxy == null) {
			if (other.proxy != null)
				return false;
		} else if (!proxy.equals(other.proxy))
			return false;
		if (resourcePath == null) {
			if (other.resourcePath != null)
				return false;
		} else if (!resourcePath.equals(other.resourcePath))
			return false;
		if (targetHost == null) {
			if (other.targetHost != null)
				return false;
		} else if (!targetHost.equals(other.targetHost))
			return false;
		if (targetPath == null) {
			if (other.targetPath != null)
				return false;
		} else if (!targetPath.equals(other.targetPath))
			return false;
		return true;
	}
	
	
}
