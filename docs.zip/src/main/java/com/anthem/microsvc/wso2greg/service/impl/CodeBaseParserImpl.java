package com.anthem.microsvc.wso2greg.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import com.anthem.microsvc.wso2greg.constants.Constants;
import com.anthem.microsvc.wso2greg.model.Config;
import com.anthem.microsvc.wso2greg.service.CodeBaseParser;
import com.anthem.microsvc.wso2greg.util.WSO2Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;

@Component
public class CodeBaseParserImpl implements CodeBaseParser {
	private static final Logger logger = LoggerFactory.getLogger(CodeBaseParser.class);
	@Override
	public String parseBootstrap(String service, String profile) throws IOException {
		logger.info("Method Enter: parseBootstrap("+service+":"+profile+")");
		
		String bootstrap = WSO2Utility.getFolderPath() + service + "\\src\\main\\resources\\bootstrap.yml";

		Yaml yaml = new Yaml();
		String configUrl = "";
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(bootstrap);
			for (Object object : yaml.loadAll(inputStream)) {
				LinkedHashMap map = (LinkedHashMap) object;
				if (!MapUtils.isEmpty(map) && map.get("spring") != null && (map.get("spring").toString().contains("profiles=" + profile))) {
					if(map.get("spring").toString().split("uri=") != null && map.get("spring").toString().split("uri=").length > 1) {
						configUrl = map.get("spring").toString().split("uri=")[1].split("}")[0] + "/" + service
								+ "-"+profile+".properties";
						break;
					}
				}
			}
		}catch(FileNotFoundException e) {
			return parseConfigJson(service, profile);
		}
		finally {
			if(inputStream != null) inputStream.close();
		}
		
		logger.info("Method Exit: parseBootstrap()");
		return configUrl;
	}

	@Override
	public Config findInFiles(Config config, String service, boolean checkConstants, boolean isVarCheck, boolean isNode) throws IOException {
		logger.info("Method Enter: findInFiles() - "+service);
		String serviceFolder = WSO2Utility.getFolderPath() + service;
		//int lineNumber = 0;
		Set<String> finalVariableNames = new HashSet<String>(); //Actual config props referred to by the application
		Map<String, String> finalMap = new HashMap<>(); //Mapping of actual config props
		
		Set<String> variablesNames = new HashSet<>(); //Contains the constants variables referring to the config properties
		Map<String, String> variablesMap = new HashMap<>();//Mapping of the constant variables to their config property
		File dir = new File(serviceFolder);
		List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE,DirectoryFileFilter.DIRECTORY);

		if(!isNode){
			for (File file : files) {
				try {
					// System.out.println(file.getCanonicalPath() + " is scanned.");
					String filePath = file.getCanonicalPath();

					if (file.isFile() && filePath.contains(".java") && !filePath.contains("Test")) {
						// System.out.println(file.getName());
						//String fileName = file.getName();
						FileReader reader = null;
						BufferedReader br = null;
						try {
							if (checkConstants && (filePath.contains("Constant") || filePath.contains("Constants") || filePath.contains("constants"))) {
								parseJavaConstantFiles(filePath, config.getKeys(), variablesNames, variablesMap);
							}
							reader = new FileReader(filePath);
							br = new BufferedReader(reader);
							String s;
							while ((s = br.readLine()) != null) {
								if(s.contains("ehub.datasource") || s.contains("ehubblue.datasource")) {
									if (s.contains("ehub.datasource")) {
										if (isVarCheck) {
											finalVariableNames.add(Constants.EHUB.get("ehub.datasource"));
										} else {
											finalMap.put(Constants.EHUB.get("ehub.datasource"), config.getProperties()
													.get(Constants.EHUB.get("ehub.datasource")).toString());
										}
									}	
									else {
										if (isVarCheck) {
											finalVariableNames.add(Constants.EHUB.get("ehubblue.datasource"));
										}else {
											finalMap.put(Constants.EHUB.get("ehubblue.datasource"), config.getProperties().get(Constants.EHUB.get("ehubblue.datasource")).toString());
										}
									}
									continue;
								}else if(s.contains("mongodb.uri")) {
									if (isVarCheck) {
										finalVariableNames.add(Constants.EHUB.get("mongodb.uri"));
									} else {
										finalMap.put(Constants.EHUB.get("mongodb.uri"), config.getProperties().get(Constants.EHUB.get("mongodb.uri")) != null ? config.getProperties().get(Constants.EHUB.get("mongodb.uri")).toString():"");
									}
								}
								//lineNumber++;
								for (String searchString : config.getKeys()) {
									if (s.contains(searchString)) { 
										if (isVarCheck) {
											finalVariableNames.add(searchString);
										} else {
											// System.out.println(searchString);
											finalMap.put(searchString, config.getProperties().get(searchString).toString());
										}

									}
								}

							}
							//reader.close();
							
						} catch (Exception e) {
							logger.error("Error while parsing java file: "+e.getCause());
							//e.printStackTrace();
						}
						finally {
							if(null != reader) reader.close();
							if(null != br) br.close();
						}
					}

				} catch (IOException e) {
					logger.error("Error while accesing file/directory: "+e.getCause());
					//e.printStackTrace();
				}
			}
			//Check for usage of constants in Java files
			for (File file : files) {
				FileReader reader = null;
				BufferedReader br = null;
				try {
					String filePath = file.getCanonicalPath();

					if (file.isFile() && filePath.contains(".java") && !(filePath.contains("Test") || filePath.contains("Constant"))) {
						reader = new FileReader(filePath);
						br = new BufferedReader(reader);
						String s;
						while ((s = br.readLine()) != null) {
							for (String searchString : variablesNames) {
								if (s.contains(searchString)) { 
									if (s.contains(searchString)) { 
										finalVariableNames.add(variablesMap.get(searchString));
									}
								}
							}

						}
						//reader.close();
						
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				
				finally {
					if(null != reader) reader.close();
					if(null != br) br.close();
				}
			}
		}else {
			for (File file : files) {
				FileReader reader = null;
				BufferedReader br = null;
				try {
					String filePath = file.getCanonicalPath();

					if (file.isFile() && filePath.contains("server.js") ) {
						reader = new FileReader(filePath);
						br = new BufferedReader(reader);
						String s;
						while ((s = br.readLine()) != null) {
							for (String searchString : config.getKeys()) {
								if (s.contains(searchString)) { 
									if (isVarCheck) {
										finalVariableNames.add(searchString);
									} else {
										// System.out.println(searchString);
										finalMap.put(searchString, config.getProperties().get(searchString).toString());
									}

								}
							}

						}
						//reader.close();
						
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
				finally {
					if(null != reader) reader.close();
					if(null != br) br.close();
				}
				
			}
		}
		
		finalVariableNames.addAll(variablesMap.values());
		boolean isMongoDependency = false;
		if(finalVariableNames.stream().anyMatch(key -> key.contains("mongodb.datasource"))) {
			isMongoDependency = true;
		}
		if(!isMongoDependency) {
			scanForMongoTemplate(finalVariableNames, service, config.getKeys());
		}
		populateFinalConfigProps(finalVariableNames, finalMap, config);
	
		logger.info("Method Exit: findInFiles() - ");
		return config;
	}
	
	private void parseJavaConstantFiles(String constantsFile, Iterable<String> keysList, Set<String> variablesNames, Map<String, String> vairablesMap) throws FileNotFoundException {
		
		File sourceFile = new File(constantsFile);
		ParseResult<CompilationUnit> parseResult = new JavaParser().parse(sourceFile);

		ParseResult<CompilationUnit> cu = new JavaParser().parse(sourceFile);
		for (TypeDeclaration typeDec : cu.getResult().get().getTypes()) {
			List<BodyDeclaration> members = typeDec.getMembers();
			if (members != null) {
				for (BodyDeclaration member : members) {
					try {
						// Check just members that are FieldDeclarations
						FieldDeclaration field = (FieldDeclaration) member;
						field.getAccessSpecifier();
						// System.out.println(field.getVariables());
						NodeList<VariableDeclarator> nodes = field.getVariables();
						Iterator<VariableDeclarator> itr = nodes.iterator();

						while (itr.hasNext()) {
							VariableDeclarator declarator = itr.next();
							String variableValue = declarator.getChildNodes().size() >2 ? declarator.getChildNodes().get(2).toString().replaceAll("\"", ""): null;
							for (String ymlKeys : keysList) {
								if (null!=variableValue && variableValue.length() > 1 && ymlKeys.contains(variableValue)) {
									// System.out.println(ymlKeys);
									String variableName = sourceFile.getName().substring(0, sourceFile.getName().indexOf(".java")+1) + declarator.getChildNodes().get(1).toString();
									vairablesMap.put(variableName, ymlKeys);
									//variablesNames.add(declarator.getChildNodes().get(1).toString());
									variablesNames.add(variableName);
								}
							}

						}
					}catch(Exception e) {
						logger.error("Error while parsing the constant variable: "+e.getMessage());
						//e.printStackTrace();
					}
					
				}
			}

		}
	}
	
	private void populateFinalConfigProps(Set<String> finalVariables, Map<String, String> finalMap, Config config) {

		Iterator<String> keysItr = config.getKeys().iterator();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			boolean found = false;
			for(String prop: finalVariables) {
				if(key.contains(prop)) {
					found = true;
					break;
				}
			}
			if(!found) {
				keysItr.remove();
			}
		}
		
		Iterator<String> propsItr = config.getProperties().keySet().iterator();
		while(propsItr.hasNext()) {
			String key = propsItr.next();
			if(!config.getKeys().contains(key)) {
				propsItr.remove();
			}
		}
		
	}
 
	@Override
	public Config parseBootstrapForMongo(Config config, String service, String profile) throws IOException {
		
		logger.info("Method Enter: parseBootstrapForMongo("+service+":)");
		
		String bootstrap = WSO2Utility.getFolderPath() + service + "\\src\\main\\resources\\bootstrap.yml";
		
		Yaml yaml = new Yaml();
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(bootstrap);
			for (Object object : yaml.loadAll(inputStream)) {
				LinkedHashMap map = (LinkedHashMap) object;
				if (!MapUtils.isEmpty(map) && (map.get("spring").toString().contains("profiles=" + profile))) {
					if(map.get("mongodb") != null && map.get("mongodb").toString().contains("uri"))
					{
						String uri = ((LinkedHashMap)map.get("mongodb")).get("uri").toString();
						config.getProperties().put("mongodb.uri", uri);
						config.getKeys().add("mongodb.uri");
						break;
					}
					
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error("Bootstrap.yml not found: "+service);
		}
		finally {
			if(inputStream != null) inputStream.close();
		}
		
		logger.info("Method Exit: parseBootstrapForMongo()");
	
		
		return config;
	}

	@Override
	public String parseConfigJson(String service, String profile) throws IOException {
		// TODO Auto-generated method stub
		
		String config = WSO2Utility.getFolderPath() + service + "\\config\\config.json";
		String configServerUrl = null;
		ObjectMapper mapper = new ObjectMapper();
		InputStream inputStream = new FileInputStream(config);
		try {
			JsonNode json = mapper.readTree(inputStream);
			JsonNode env = json.get(profile);
			configServerUrl = env.get("configServerUrl").asText();
		} catch (JsonProcessingException e) {
			logger.error("Error while parsing parsing config.json: "+e.getCause());
		} catch (IOException e) {
			logger.error("Error while parsing parsing config.json: "+e.getCause());
		}
		finally {
			inputStream.close();
		}
		
		return configServerUrl;
	}
	
	private void scanForMongoTemplate(Set<String> finalVariables, String service, Set<String> configKeys){
		String serviceFolder = WSO2Utility.getFolderPath() + service;
		
		File dir = new File(serviceFolder);
		List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE,DirectoryFileFilter.DIRECTORY);

		for (File file : files) {
			try {
				String filePath = file.getCanonicalPath();
				if (file.isFile() && filePath.contains(".java") && !filePath.contains("Test")) {
					//String fileName = file.getName();
					FileReader reader  = null;
					try {
						reader = new FileReader(filePath);
						BufferedReader br = new BufferedReader(reader);
						String s;
						while ((s = br.readLine()) != null) {
							if(s.contains("MongoTemplate") || s.contains("MongoRepository")) {
									for(String key : configKeys) {
										if(key.contains("spring.data.mongodb.uri") || key.contains("mongodb.datasource.uri") ) {
											finalVariables.add(key);
											break;
										}
									}
									
								}
							}
							
						//reader.close();
						
					} catch (Exception e) {
						logger.error("Error while parsing java file: "+e.getCause());
						//e.printStackTrace();
					}
					
					finally {
						if(null != reader) reader.close();
					}
				}

			} catch (IOException e) {
				logger.error("Error while accesing file/directory: "+e.getCause());
				//e.printStackTrace();
			}
		}
	
		
	}
	
}
