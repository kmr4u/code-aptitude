package com.anthem.microsvc.wso2greg.service;

public interface SCMCloneService {

	public void cloneRepo(String domain, String service, String[] cred) throws Exception;
}
